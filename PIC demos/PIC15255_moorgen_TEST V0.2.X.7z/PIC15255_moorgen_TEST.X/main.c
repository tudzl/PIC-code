 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
//V0.2 Key INT OK, RA5 PWM control based on TMR1/TMR2 need to improve!
//Need to add touch

//V0.1 basic function test OK, UART printf is OK, 19200 Baudrate
#include "mcc_generated_files/system/system.h"
#include <xc.h>

/*
    Main application
*/
uint8_t TMR_500ms_INT_flag = 0;
uint16_t V_bat_mV = 0;
uint16_t V_in_mV =0;
uint8_t Light_ON = 0 ;
uint8_t KEY_cnt = 0 ;
#define ADC_sample_scale 2
#define ADC_resolution 1024

       

int main(void)
{
    SYSTEM_Initialize();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 
    
    printf("Moorgen D38 Corsa ITS touch test demo!");
    printf("-Version 0.2, 17.Nov.2024 by Zell-\r\n");
    printf("--FW code compiled: %s %s--\n", __DATE__, __TIME__);
    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 
    Light_ON = 0;

    while(1)
    {
        if(TMR_500ms_INT_flag){
            TMR_500ms_INT_flag = 0;
            IO_RA0_WLED_Toggle();
            V_in_mV = ADC_GetConversion(channel_ANA3_Vin);
            printf(">>Vin raw: %d\r\n", V_in_mV);
            V_in_mV = V_in_mV*ADC_sample_scale*3300/1024;
            printf("Vin: %d mV\r\n", V_in_mV);
            V_bat_mV = ADC_GetConversion(channel_ANA2_Vbat);
            printf("V_akku raw: %d\r\n", V_bat_mV);
            V_bat_mV = V_bat_mV*ADC_sample_scale*3300/1024;
            printf("VAkku: %d mV\r\n", V_bat_mV);
            //ADC_StartConversion();
            //ADC_SelectChannel
            printf("Key: %d\r\n", KEY_cnt);
            if(1==KEY_cnt%2){
                Light_ON = 1;
            }
            else Light_ON = 0;
            
            CLRWDT();
        }
    }    
}