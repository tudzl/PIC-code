/*
    (c) 2019 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
 */

/**
  Section: Included Files
 */

#include <xc.h>
#include "pcmc_modblk3.h"
#include "../cog2.h"
#include "../pwm12.h"
#include "../prg1.h"

/**
  Section: PCMC Modulator Block APIs
 */

void PcmcModBlock3_Initialize(void) {
    PcmcModBlock3_PPS_Setup();
    PcmcModBlock3_PRG_StartSequence();
}

void PcmcModBlock3_PPS_Setup(void) {
    RD5PPS = 11; //COG2C 
    RD4PPS = 12; //COG2D
}

void PcmcModBlock3_COG_Start(void) {
    COG2CON0bits.EN = 1;
}

void PcmcModBlock3_COG_Stop(void) {
    COG2CON0bits.EN = 0;
}

void PcmcModBlock3_PWM_Start(void) {
    PWM12_Start();
}

uint16_t PcmcModBlock3_PWM_GetDutyCycle(void) {
    // Read data
    uint16_t data = ((uint16_t) PWM12DCH) << 8;
    data |= ((uint16_t) PWM12DCL);

    return data;
}

void PcmcModBlock3_PWM_SetDutyCycle(uint16_t DCvalue) {
    PWM12_DutyCycleSet(DCvalue);
    PWM12_LoadBufferSet();
}

uint16_t PcmcModBlock3_PWM_BlankingGet(void) {
    // Read data
    uint16_t data = ((uint16_t) COG2BLKR);

    return data;
}

void PcmcModBlock3_PWM_BlankingSet(uint16_t BlankingValue) {
    COG2BLKR = (uint8_t)(BlankingValue & 0x00FF);
}

void PcmcModBlock3_PRG_StartSequence(void) {
    while(!PRG1_IsReady());
    PRG1_StartRampGeneration();
}

 