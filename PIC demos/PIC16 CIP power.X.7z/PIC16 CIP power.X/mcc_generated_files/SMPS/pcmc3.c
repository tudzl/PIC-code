/*
    (c) 2019 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
 */

/**
  Section: Included Files
 */

#include "pcmc3.h"
#include "compensator_blk3.h"
#include "pcmc_modblk3.h"

/**
  Section: PCMC APIs
 */

void PCMC3_Initialize(void) {
    PcmcModBlock3_PPS_Setup();
    PCMC3_SoftStart();
}

void PCMC3_SoftStart(void) {
    uint16_t PWMlimit, DAClimit, BLANKlimit;
    uint16_t ctr = 0;

    PWMlimit = PcmcModBlock3_PWM_GetDutyCycle();
    BLANKlimit = PcmcModBlock3_PWM_BlankingGet();
    DAClimit = CompensatorBlock3_DAC_ReadInputData();

    CompensatorBlock3_DAC_LoadInputData(0);
    PcmcModBlock3_PWM_SetDutyCycle(0);
    PcmcModBlock3_PWM_BlankingSet(0);

    CompensatorBlock3_OPA_Start();
    PcmcModBlock3_PWM_Start();
    // fire up the PRG generation
    PcmcModBlock3_PRG_StartSequence();
    PcmcModBlock3_COG_Start();

    while ((ctr++) < PWMlimit) {
        if(ctr <= BLANKlimit){
            PcmcModBlock3_PWM_BlankingSet(ctr);
        }
        PcmcModBlock3_PWM_SetDutyCycle(ctr);
    }

    ctr = 0;

    while ((ctr++) < DAClimit) {
        CompensatorBlock3_DAC_LoadInputData(ctr);
    }
}

void PCMC3_SetReference(uint16_t dacValue) {
   CompensatorBlock3_DAC_LoadInputData(dacValue);
}

uint16_t PCMC3_GetReference(void){
   return CompensatorBlock3_DAC_ReadInputData();
}

void PCMC3_PRG_StartSequence(void){
    PcmcModBlock3_PRG_StartSequence();
}
