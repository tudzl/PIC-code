/**
  PWM12 Generated Driver File

  @Company
    Microchip Technology Inc.

  @File Name
    pwm12.c

  @Summary
    This is the generated driver implementation file for the PWM12 driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides implementations for driver APIs for PWM12.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1779
        Driver Version    :  2.01
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.36 and above or later
        MPLAB             :  MPLAB X 6.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

/**
  Section: Included Files
*/

#include <xc.h>
#include "pwm12.h"

/**
  Section: PWM12 APIs
*/

void PWM12_Initialize(void)
{
    // set the PWM12 to the options selected in the User Interface

     //PHIE disabled; DCIE disabled; OFIE disabled; PRIE disabled; 
    PWM12INTE = 0x00;

     //PHIF cleared; OFIF cleared; DCIF cleared; PRIF cleared; 
    PWM12INTF = 0x00;

     //PS Divide_clock_src_by_4; CS FOSC; 
    PWM12CLKCON = 0x20;

     //LDS LD5_trigger; LDT disabled; LDA do_not_load; 
    PWM12LDCON = 0x00;

     //OFM independent_run; OFS OF5_match; OFO match_incrementing; 
    PWM12OFCON = 0x00;

     //PWM12PHH 0; 
    PWM12PHH = 0x00;

     //PWM12PHL 0; 
    PWM12PHL = 0x00;

     //PWM12DCH 0; 
    PWM12DCH = 0x00;

     //PWM12DCL 4; 
    PWM12DCL = 0x04;

     //PWM12PRH 0; 
    PWM12PRH = 0x00;

     //PWM12PRL 7; 
    PWM12PRL = 0x07;

     //PWM12OFH 0; 
    PWM12OFH = 0x00;

     //PWM12OFL 7; 
    PWM12OFL = 0x07;

     //PWM12TMRH 0; 
    PWM12TMRH = 0x00;

     //PWM12TMRL 0; 
    PWM12TMRL = 0x00;

     //MODE standard_PWM; POL active_hi; EN enabled; 
    PWM12CON = 0x80;

}    


void PWM12_Start(void)
{
    PWM12CONbits.EN = 1;		
}

void PWM12_Stop(void)
{
    PWM12CONbits.EN = 0;		
}

bool PWM12_CheckOutputStatus(void)
{
    return (PWM12CONbits.OUT);		
}

void PWM12_LoadBufferSet(void)
{
    PWM12LDCONbits.LDA = 1;		
}

void PWM12_PhaseSet(uint16_t phaseCount)
{
    PWM12PHH = (phaseCount>>8);        //writing 8 MSBs to PWMPHH register
    PWM12PHL = (phaseCount);           //writing 8 LSBs to PWMPHL register
}

void PWM12_DutyCycleSet(uint16_t dutyCycleCount)
{
    PWM12DCH = (dutyCycleCount>>8);	//writing 8 MSBs to PWMDCH register
    PWM12DCL = (dutyCycleCount);	//writing 8 LSBs to PWMDCL register		
}

void PWM12_PeriodSet(uint16_t periodCount)
{
    PWM12PRH = (periodCount>>8);	//writing 8 MSBs to PWMPRH register
    PWM12PRL = (periodCount);	//writing 8 LSBs to PWMPRL register		
}

void PWM12_OffsetSet(uint16_t offsetCount)
{
    PWM12OFH = (offsetCount>>8);	//writing 8 MSBs to PWMOFH register
    PWM12OFL = (offsetCount);	//writing 8 LSBs to PWMOFL register		
}

uint16_t PWM12_TimerCountGet(void)
{
    return ((uint16_t)((PWM12TMRH<<8) | PWM12TMRL));       		
}

bool PWM12_IsOffsetMatchOccured(void)
{
    return (PWM12INTFbits.OFIF);		
}

bool PWM12_IsPhaseMatchOccured(void)
{
    return (PWM12INTFbits.PHIF);	
}

bool PWM12_IsDutyCycleMatchOccured(void)
{
    return (PWM12INTFbits.DCIF);		
}

bool PWM12_IsPeriodMatchOccured(void)
{
    return (PWM12INTFbits.PRIF);		
}

/**
 End of File
*/


