/******************************************************************************/
/*smart device demo pcb 1.0 TN903`BT740 control PIC24fv32KA302     */
//Achtung Data 2048 Bytes! if available bytes less than 20%,  sprintf %f cause program halt bug!!
//while loop processing time about 16.88 ms
//SPI 1MHZ, IIC 340KHz@ BRG=0x25
/*Absolute Resolution 0.25mA @ 10mOhm Resistor */
/* fixed 1.25mV per LSB for V bus*/
//Assumg  MAX 65.536A, current_LSB = 2mA/LSB, CAL 2560
//2019.5.28  test __EEPROM uint8_t serialNum = 1234;
//2019.5.17  test sleep mode 
//2019.4.10 V2.0  FPS change mode mah mws improve ok 
//2019.4.10 V1.1  float display ok 
//*2019.3.26 V1.0  all function ok, to add Energy mode, mwh  mah function
/* 2019.3.6 v0.5
 * PIC sys CLK 32MHZ?8Mhz + PLL?, IIC 357Khz @ SSPADD= 0x27? PIN CLKO 16Mhz
 * INA233 400Khz IIC       slave   address     (0x40) ox80     LSB--MSB
 *Shunt voltage input range ?81.92 to 81.9175 mV 2.5uV/bit
 *fixed 1.25mV per LSB for V bus
 * 2.5mA /LSB @ 1mOhm shunt current resistor1
 * 1.1ms for both convertion time, Average = 4
 * spi 1mHz FOR OLED Driving, idle high active low mode 3
 *MCP9808 temp. sensor address 0011A2A1A0=  0011000  0x18<<1  0x30  ; MSB--LSB
 *TA: AMBIENT TEMPERATURE REGISTER (? ADDRESS ?0000 0101?b) 
 Temperature res 0.0625 degree/LSB  
 *  EEDATA Functions for PIC24FxxK Devices   defined in libpic30.h */
/******************************************************************************/


/* PIC24FV16KA302 smart device v1.0 board,
 * IIC1: SDA1/SCL1 ---> INA233
 * SPI2: SCD2/SDO2 ---> OLED
 * SPI mode 3 SCK idle high,
 * File:   mainXC16.c
 * V1.0, need to improve freq, ID mode
 * Author: ZL
 * Achtung: #define UART1_CONFIG_RX_BYTEQ_LENGTH 1   reffers to uart receive buffer!
/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using MPLAB(c) Code Configurator

 */

//----------pin--------------------
//RA0 pin2  AN0  -- ws2812 light_sda
//RA1 pin3  LED indication , flashes
//RB2 pin6  UART1 RX
//RB3 pin7  AN5 V_akku
//RB4 pin11 TN903 ACT
//RB5 Pin14 SCK2  (SPI))  OLED
//RB6 Pin15 SDO2  (SPI))   OLED
//RB7 pin16  UART1 TX
//RB8 pin17  UART1 CTS
//RB9 pin18  UART1 RTS  output
//RB10 Pin21 SDI1
//RB11 pin22 SCK1
//RB12 pin23 AN12
//RB14 pin25  EXRNT1 ,(RTCC) NT1 key inputs(motor trigger) with ADC sampling key voltage, rise must > 2.2V
//---OLED SPI interface------------
//RB15  OLED  D/C#
//SCK2 SPI2
//reset OLED
//     LATAbits.LATA4 = 1;
//    LATAbits.LATA3 = 1;
//---OLED SPI interface end----------
//~~~~~~~~~~~~~~~~~RGB LED WS2812!!!!!!!!!!!!!!!!!!!!!!!!!!!!!--------
// Light_SDA  LATAbits.LATA0

#define SYS_FREQ         32000000L
#define FCY   SYS_FREQ/2
#define Reset() __asm__ volatile ("reset")
#define  NOP()  __asm__ volatile ("nop")


#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/adc1.h"
#include <stdlib.h>      //Data Conversion Functions
#include <string.h>   // memset
#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */
#include <stdio.h>
#include <libpic30.h>  //delay us
#include "oled_driver/Adafruit_SSD1306.h" //FC buffer
#include "oled_driver/oledfont.h"
//#include "WS2812_head.h"

//  EEPROM data
int serialNum = 1234;
_prog_addressT EE_Ser_Addr = 0x7ffe00;

extern int eedata;


//

//------------------OLED ---------------
//SPI SCK SDO
//RA3 reset
//RB15 C/D signal
uint8_t SSH1103 = 1; // 0 . ssd1306 driver;  1, ssh1103 driver  bigger OLED
//----------------TN903----------------
//RB4 pin11 TN903 ACT
//SPI1 slave mode 3   SPIROV must be cleared by User
uint8_t SPI1_buf[8]; //store tmp data from sensor
double T_object = 0;
float T_PCB = 0;
int8_t T_limit_H = 70;
int8_t T_limit_L = 0;
int8_t T_limit_Critical = 90;
uint8_t SPI1_buf_full = 0;
uint8_t SPI1_buf_len = 8;
uint8_t SPI1_read(void);
void TN903_ACT(void);
void TN903_ACT_Hi(void);
int8_t Reg_T_object = 0x4c;
int8_t Reg_T_Module = 0x66;
int8_t Reg_Emissivity = 0x53;
//int8_t Parse_TN903_data_test(uint8_t *Rxbuf, uint8_t Taget_type, float *parsed_val);
int8_t Parse_TN903_data(uint8_t *Rxbuf, uint8_t Taget_type, uint8_t Taget_type2, double *parsed_val);
//-------------BT 740---------------------
unsigned char UART1_RX_cnt = 0;
#define BTdata_BUFFER_SIZE  4
uint8_t BT_RX_buf[BTdata_BUFFER_SIZE]; //store data from BT740

void BT740_init(void);
void BT740_startup(void);
uint8_t BT_init = 0;
uint8_t BT_CHKSUM = 1;
uint8_t BT_data_mode_simple = 0; // 0 send only T-object; 1 send T ambient and object
uint8_t BT_ECHO = 1;
//void BT740_T_data_send(double T);
void BT740_T_data_send(int T);
void U1RX_interrupt_EN(void); // 1 EN  IEC0bits.U1RXIE = 1;  /
void U1RX_interrupt_disable(void);
////----------------INA233----------------
//#define V_scale 4;
//#define V_scale2 10;
////&&&&&&&&&&&&&&&&&&&$$$$$$$$***********MCP9808************************-
//uint16_t MCP9808 = 0x19; // INA233 PCB2 0x19
//uint8_t TA_reg = 0x05; //AMBIENT TEMPERATURE REGISTER; bit 12 SIGN bit  0 @>0degree
//uint8_t mcp_temp_H = 0; //upper bits
//uint8_t mcp_temp_L = 0;
//double Temperature = 0;
//int8_t T_limit_H = 40;
//int8_t T_limit_L = 5;
//int8_t T_limit_Critical = 50;


//----------------IIC-----------------------
//#define SLAVE_I2C_GENERIC_RETRY_MAX           6
//#define SLAVE_I2C_GENERIC_DEVICE_TIMEOUT      3   // define slave timeout
//uint16_t INA233_get_value(uint8_t reg);

//----------------LED SSR Pin ---------------
#define LED_ON()  LATAbits.LATA1=1
#define LED_OFF()  LATAbits.LATA1=0
//#define SSR_ON() LATAbits.LATA0 = 1 //SSR high alarm
//#define SSR_OFF() LATAbits.LATA0 = 0 //SSR OFF


//=======================OLED=================
unsigned char SPI_mode_OLED = 1; //SPI mode using SPI2
void OLED_init(void);
void drawPixel(int16_t x, int16_t y, uint16_t color);
void SPI_disable(void);
void SPI_enable(void);
void ssd1306_SPI_display(void);
//void ssd1306_SPI_LOGO_display(void);
void ssd1306_SPI_DrawLine(uint8_t ln);
//void ssd1306_SPI_DrawLine1(void);
void ssd1306_command(uint8_t c);
void ssd1306_data(uint8_t c);
void ssd1306_SPI_command(uint8_t c);
void SSD1306_clearDisplay(void);
//void buffer_fill_char(void);
void OLED_string(char* str, short x, short y);
char OLED_FontSize = 0; // 0 for small size
void set_font_size(char t);


//---------------------ADC proto---------------
void ADC1_Disable(void);
void ADC1_Enable(void);
unsigned int adc_12bit(void);
unsigned int ADC_conversion = 0; //0-4095 Raw value
double Vref_ADC_BG = 2048; //2*Vbg  milli voltage @ 3.3V AVdd input; Band Gap Reference Voltage 1.024V
//double Vref_ADC = 4096; //milli voltage
int8_t V_ratio = 2; // Wiederstand Voltage ratio

/////////////////////////////////////////////////////////////////////////
//uint8_t writeData;
//uint8_t readData;

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$   Globle control vars  $$$$$$$$$$$$$$$$$$$
//unsigned char slave_mode = 1;

//punsigned char sys_mode_master = 1; // master active sending RF
//unsigned char sys_mode_slave = 0; // slave active receiving RF
//uint8_t RF_heartbeat_EN =0; //test
unsigned char Sys_Frequncy = 32; //16Mhz or 4Mhz without PLL
#define CCP3PRL_default 0x400  //15.6KHz  0x400 1024
unsigned int Refresh_intval = 239; //ms    4fps 250
unsigned int Refresh_intval_s = 86; //ms   10 fps  100ms
unsigned int Refresh_intval_ss = 36; //ms   20fps   50ms
unsigned int Refresh_intval_onesec = 989; //ms   1fps   1s
unsigned int fps_tmp = 4;
unsigned char sleep_ENA = 0;
unsigned int sleep_interval = 4;



/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/

char tmp_string[21];
unsigned int Refresh_intval_tmp = 0;

/*
                         Main application
 */
int main(void) {
    // initialize the device
    //char tmp_string[21];
    SYSTEM_Initialize();
    // ADC1_Initialize();
    //ADC_conversion = adc_12bit();
    U1RX_interrupt_disable();
    Refresh_intval_tmp = Refresh_intval;
    //LED_ON();

    //_erase_eedata_all(); //test only.
    
    
    //LED_OFF();

    LED_ON();

    EE_Ser_Addr = 0x7ffe00;
    _write_eedata_word(EE_Ser_Addr, serialNum); //about 2.4ms
    _wait_eedata();
     //LED_OFF();
     
    EE_Ser_Addr += 2;
    _write_eedata_word(EE_Ser_Addr, serialNum + 1);
    _wait_eedata();
     //LED_ON();
     
     LED_OFF();
    unsigned int eedata_tmp;
    // unsigned int eedata_tmp = Read_EEPROM_data(0);
     //eedata_tmp = EEData_Read();
     eedata_tmp = Read_EEPROM_data(2); //less than 800ns
     _wait_eedata();
     
     eedata_tmp = Read_EEPROM_data(0);
     _wait_eedata();
     
      LED_ON();
    //LED_OFF();
    
    OLED_init();
    __delay_ms(100);
    ClrWdt();
    LED_OFF();
    SPI_enable(); //SPI2  oled
    ssd1306_SPI_display(); //display logo
    __delay_ms(1000);
    ClrWdt();
    SSD1306_clearDisplay();
    //__delay_ms(10);
    //ssd1306_SPI_LOGO_display(); //display QR code logo
    __delay_ms(1000);
    ClrWdt();
    SSD1306_clearDisplay();
    uint16_t cyc = 1;
    set_font_size(1);
    sprintf(tmp_string, "Init.!");
    OLED_string(tmp_string, 0, 0);

    sprintf(tmp_string, "SerNr.%d", eedata_tmp);
    OLED_string(tmp_string, 0, 4);


    ssd1306_SPI_display(); //draw
    __delay_ms(600);
    ClrWdt();
    //SSD1306_clearDisplay();
    uint8_t TN_flag = 0;
    uint8_t idx = 0;

    ADC1_Enable();
    __delay_ms(100);
    if (BT_init) {

        OLED_string("BT740init...", 0, 2);
        ssd1306_SPI_display(); //draw
        BT740_init();
        ClrWdt();
        __delay_ms(500);
    } else BT740_startup();

    OLED_string("SmartDevice", 0, 0);

    //int16_t T_test = 0;
    TN903_ACT(); //not working
    uint16_t SPI1_cnt = 0;
    uint16_t BT_RX_cnt = 0;
    SPI1_STATUS SPI1_status;
    float V_LFP = 0;
    U1RX_interrupt_EN();
    ClrWdt();
    while (1) {

        LED_ON();
        LATBbits.LATB4 = 0;
        //TN903_ACT();




        idx = 0;
        //contains bug! 2019.3.22

        //        if (BT_RX_cnt >= 8) {
        //            while (UART1_RX_DATA_AVAILABLE & UART1_StatusGet()) {
        ////URXDA =0? RIDLE=1
        //
        //                BT_RX_buf[idx] = UART1_Read();
        //                idx++;
        //                if (idx >= 32)
        //                    break;
        //
        //            }
        //
        //        }

        // sprintf(tmp_string, "T:%5.1f ", 25);  //bug??
        //sprintf(tmp_string, "BT_R%d:%X %X ", BT_RX_cnt, BT_RX_buf[0], BT_RX_buf[1]);
        sprintf(tmp_string, "BT_RX:%X %X %X %X", BT_RX_buf[0], BT_RX_buf[1], BT_RX_buf[2], BT_RX_buf[3]);
        set_font_size(0);
        OLED_string(tmp_string, 0, 5);


        sprintf(tmp_string, "SPI:%d  BT:%d", SPI1_cnt, BT_RX_cnt);
        //set_font_size(0);
        OLED_string(tmp_string, 0, 6);
        //------------phase 3 --------run time UI

        //counter = I2C1_ErrorCountGet();
        // sprintf(tmp_string, "Run:%d ", cyc);
        sprintf(tmp_string, "Run:%d  VA:%5.3F V", cyc, (double) V_LFP);
        set_font_size(0);
        OLED_string(tmp_string, 0, 7);
        set_font_size(1);
        // ssd1306_SPI_display();


        if (cyc % 4 == 0) {
            //----------phase 1-------SPI TN903 read data routine---read interval?


            if (SPI1STATbits.SPIROV == true) //Receive FIFO Empty bit 
            {
                //SPI1_Exchange8bitBuffer(0, 5, SPI1_buf); //not working
                // if (SPI1STATbits.SRXMPT == false) //Receive FIFO Empty bit 
                for (idx = 0; idx < SPI1_buf_len; idx++) {
                    //SPI1_buf[idx] = SPI1_Exchange8bit(SPI1_DUMMY_DATA); //bug?? first read OK!  working on!
                    SPI1_buf[idx] = SPI1BUF; //test
                    //SPI1_buf[idx] = SPI1_read(); //bug?
                    SPI1_cnt++;

                }

                SPI1STATbits.SPIROV = 0;
            }

            SPI1_status = SPI1_StatusGet();

            // }
            //             SPI1_buf[0]=0x4c;
            //             SPI1_buf[1]=0x12;
            //            SPI1_buf[2]=0xbc;
            TN_flag = Parse_TN903_data(SPI1_buf, Reg_T_object, Reg_T_Module, &T_object); //bugs!!  PCB temp. 0x66
            //TN_flag = Parse_T_object_data(SPI1_buf, Reg_T_object, &T_object);   //  //Reg_T_object= 0x4c; 


            //            if (TN_flag )
            //                sprintf(tmp_string, "T%d:%5.1f C", TN_flag, T_object);
            if (TN_flag == 1)
                sprintf(tmp_string, "T_O:%5.1f C", T_object);
            else if (TN_flag == 2)
                sprintf(tmp_string, "T_L:%5.1f C", T_object);
            else if (TN_flag == 3)
                sprintf(tmp_string, "Ems.:0.%d ", (uint8_t) T_object);
            else sprintf(tmp_string, "T_O: Wait... ");
            //sprintf(tmp_string, "Run:%d,Er.%d ", cyc, counter);
            set_font_size(1);
            OLED_string(tmp_string, 0, 2);

            set_font_size(0);
            sprintf(tmp_string, "SPI:%X %X %X %X %X", SPI1_buf[0], SPI1_buf[1], SPI1_buf[2], SPI1_buf[3], SPI1_buf[4]);
            OLED_string(tmp_string, 0, 4);



            //            if (SPI1_status==SPI1_RECEIVE_BUFFER_FULL)
            //                 sprintf(tmp_string, "RBF:%X ",SPI1_status);
            //            if (SPI1_status==SPI1_RECEIVE_OVERFLOW)
            //                 sprintf(tmp_string, "OverFlow:%X ",SPI1_status);          
            //            if (SPI1_status==SPI1_RECEIVE_FIFO_EMPTY)
            //                 sprintf(tmp_string, "FIFOE:%X ",SPI1_status); 
            //            if (SPI1_status==SPI1_SHIFT_REGISTER_EMPTY)
            //                 sprintf(tmp_string, "SHFE:%X ",SPI1_status); 

            //sprintf(tmp_string, "ST:%X ", SPI1_status);
            // OLED_string(tmp_string, 0, 5);


            //----------phase 2-------BT SPP process

            LATBbits.LATB4 = 1; //test
            if ((BT_data_mode_simple) &&(TN_flag == 1)) {

                for (idx = 0; idx < 3; idx++) {
                    BT740_T_data_send(SPI1_buf[idx]);

                    __delay_us(10);
                }//send first 3 bytes
                //BT740_T_data_send((int) 35.6); //test dummy date
                if (BT_CHKSUM) {
                    BT740_T_data_send(SPI1_buf[3]);
                } //send check sum= Head+MSB+LSB

                BT740_T_data_send((uint8_t) (cyc / 4));
                //finish sending data


            } else if (BT_data_mode_simple == 0) {
                for (idx = 0; idx < 3; idx++) {
                    BT740_T_data_send(SPI1_buf[idx]);

                    __delay_us(10);
                }//send first 3 bytes
                //BT740_T_data_send((int) 35.6); //test dummy date
                if (BT_CHKSUM) {
                    BT740_T_data_send(SPI1_buf[3]);
                } //send check sum= Head+MSB+LSB

                BT740_T_data_send((uint8_t) (cyc / 4));
                //finish sending data
            }
            /////%%%%%%%%%%%%%%%%%%% BT send data end  %%%%%%%%%%%%%%%%%%
            if (UART1_RX_cnt >= BTdata_BUFFER_SIZE) {
                //                for (idx = 0; idx < UART1_RX_cnt; idx++) {
                //                    BT_RX_buf[idx] = UART1_Read();
                //                }
                //                UART1_RX_cnt = 0; // reset?
                //            }
                //                 do {
                idx = 0;
                do {
                    // if (UART1_TRANSFER_STATUS_RX_DATA_PRESENT & UART1_TransferStatusGet()) {
                    BT_RX_buf[idx] = UART1_Read();
                    idx++;
                    // }

                    // }

                } while (idx < BTdata_BUFFER_SIZE);

                BT_RX_cnt += UART1_RX_cnt;
                UART1_RX_cnt = 0;
            }




            /////%%%%%%%%%%%%%%%%%%% BT RX data end  bug!!!  %%%%%%%%%%%%%%%%%%




            //--------AKKU Spanung measure
            ADC1_Enable();
            ADC1_ChannelSelect(ADC1_CHANNEL_AN5); //AN5  ,Vb
            ADC_conversion = adc_12bit();
            V_LFP = (float) ADC_conversion;
            V_LFP = V_LFP * Vref_ADC_BG / 4095.0; //in mili volt
            V_LFP = V_ratio * V_LFP / 1000;



            LATBbits.LATB4 = 0; //test
            if (SPI1_cnt > 65500) SPI1_cnt = 0; //reset SPI1_cnt
            if (cyc > 65500) cyc = 0; //reset
            //            set_font_size(1);
        }
        ssd1306_SPI_display();


        LED_OFF();
        //TN903_ACT();

        // Add your application code
        if ((sleep_ENA)&&(cyc % sleep_interval == 0))
            Sleep();
        //Sleep();
        //? Sleep Mode: The CPU, system clock source and any peripherals that operate on the
        //system clock source are disabled. This is the lowest power mode for the device.
        //? Idle Mode: The CPU is disabled, but the system clock source continues to operate.
        //Peripherals continue to operate, but can optionally be disabled.
        __delay_ms(Refresh_intval_tmp);
        ClrWdt(); // 2.048s    
        cyc++;
        //RGB_LED_Reset();
    }// end of while

    return -1;
}

unsigned int adc_12bit(void) {
    //ADC1_ChannelSelect(ADC1_CHANNEL_AN15);//works
    //ADC1_ChannelSelect(ADC1_CHANNEL_AN10);
    //NOP();
    ADC1_Start();
    __delay_us(20);
    //for (int i = 0; i < 1000; i++) {
    //}
    ADC1_Stop();
    //__delay_us(18);
    //LATAbits.LATA1=0;
    //LATAbits.LATA1=1;
    //28uS
    unsigned int conversion = 0;

    while (!ADC1_IsConversionComplete()) {
        ADC1_Tasks();
    }
    conversion = ADC1_ConversionResultGet();
    return conversion; //12bit
}

void ADC1_Disable(void) {

    AD1CON1bits.ADON = 0;
}

void ADC1_Enable(void) {

    AD1CON1bits.ADON = 1;
}

//OLED display:

void OLED_init(void) {
    //init SSD1306 OLED
    //LATAbits.LATA1 = 1; //led

    //reset
    LATAbits.LATA4 = 1; //unused for led
    LATAbits.LATA3 = 1; //working  oled reset
    __delay_ms(1);
    LATAbits.LATA4 = 0;
    LATAbits.LATA3 = 0;
    __delay_ms(100);
    LATAbits.LATA4 = 1;
    LATAbits.LATA3 = 1;
    __delay_us(20);
    SPI_enable();
    //uint8_t SPI_WriteBuffer[MY_BUFFER_SIZE];
    LATBbits.LATB15 = 0; //CD signal to low for cmd
    // Init sequence 1.3 or  0.96 OLED
    if (SSH1103 == 1) {//SSH1106

        ssd1306_command(SH1106_DISPLAYOFF); // 0xAE
        ssd1306_command(SH1106_SETDISPLAYCLOCKDIV); // 0xD5
        ssd1306_command(0x80); // the suggested ratio 0x80
        ssd1306_command(SH1106_SETMULTIPLEX); // 0xA8
        ssd1306_command(SSH1103_LCDHEIGHT - 1); //0x3F  63
        ssd1306_command(SH1106_SETDISPLAYOFFSET); // 0xD3
        ssd1306_command(0x00); // no offset

        ssd1306_command(SH1106_SETSTARTLINE | 0x0); // line #0 0x40
        ssd1306_command(SH1106_CHARGEPUMP); // 0x8D
        ssd1306_command(0x14); //vccstate
        ssd1306_command(SH1106_MEMORYMODE); // 0x20
        ssd1306_command(0x00); // 0x0 act like ks0108
        ssd1306_command(SH1106_SEGREMAP | 0x1);
        ssd1306_command(SH1106_COMSCANDEC);
        ssd1306_command(SH1106_SETCOMPINS); // 0xDA
        ssd1306_command(0x12);
        ssd1306_command(SH1106_SETCONTRAST);
        ssd1306_command(0xCF);
        ssd1306_command(SH1106_SETPRECHARGE); // 0xd9
        ssd1306_command(0xF1);
        ssd1306_command(SH1106_SETVCOMDETECT); // 0xDB
        ssd1306_command(0x40);
        ssd1306_command(SH1106_DISPLAYALLON_RESUME); // 0xA4
        ssd1306_command(SH1106_NORMALDISPLAY); // 0xA6
        //--turn on oled panel
        ssd1306_command(SH1106_DISPLAYON); //--turn on oled panel

    } else { //SSD1306
        ssd1306_command(SSD1306_DISPLAYOFF); // 0xAE
        ssd1306_command(SSD1306_SETDISPLAYCLOCKDIV); // 0xD5 ??
        ssd1306_command(0x80); // the suggested ratio 0x80

        ssd1306_command(SSD1306_SETMULTIPLEX); // 0xA8
        ssd1306_command(SSD1306_LCDHEIGHT - 1); //63   0x3F  diff to SSH1106

        ssd1306_command(SSD1306_SETDISPLAYOFFSET); // 0xD3
        ssd1306_command(0x0); // no offset
        ssd1306_command(SSD1306_SETSTARTLINE | 0x0); // line #0
        ssd1306_command(SSD1306_CHARGEPUMP); // 0x8D
        ssd1306_command(0x14);

        ssd1306_command(SSD1306_MEMORYMODE); // 0x20
        ssd1306_command(0x00); // 0x0 act like ks0108
        ssd1306_command(SSD1306_SEGREMAP | 0x1);
        ssd1306_command(SSD1306_COMSCANDEC);


        ssd1306_command(SSD1306_SETCOMPINS); // 0xDA   ??
        ssd1306_command(0x12);
        ssd1306_command(SSD1306_SETCONTRAST); // 0x81  ??
        ssd1306_command(0xCF);

        ssd1306_command(SSD1306_SETPRECHARGE); // 0xd9
        ssd1306_command(0xF1);
        ssd1306_command(SSD1306_SETVCOMDETECT); // 0xDB
        ssd1306_command(0x40);
        ssd1306_command(SSD1306_DISPLAYALLON_RESUME); // 0xA4
        ssd1306_command(SSD1306_NORMALDISPLAY); // 0xA6

        ssd1306_command(SSD1306_DEACTIVATE_SCROLL);

        //ssd1306_command(SH1106_DISPLAYALLON);
        ssd1306_command(SSD1306_DISPLAYON); //--turn on oled panel  0xA5  Entire Display ON
    }
    //SPI_disable();
}

void ssd1306_SPI_command(uint8_t c) {

    // SPI

    LATBbits.LATB15 = 0;
    SPI2_Exchange8bit(c);
    LATBbits.LATB15 = 1;
}

void ssd1306_Data(uint8_t c) {

    // SPI

    LATBbits.LATB15 = 1; //D/C# pin high
    SPI2_Exchange8bit(c);
    LATBbits.LATB15 = 1;
}

/*
void ssd1306_SPI_LOGO_display(void) {
    //need rewrite!
    uint16_t i = 0;
    uint16_t length = sizeof (FC_buffer);
    if (length >= sizeof (gImage_QR_logo)) {
        length = sizeof (gImage_QR_logo);
        for (i = 0; i < (length); i++) {
            FC_buffer[i] = gImage_QR_logo[i]; //logo
        }
    } else {
        length = sizeof (FC_buffer);
        for (i = 0; i < (length); i++) {

            FC_buffer[i] = gImage_QR_logo[i]; //logo

        }
    }

    //finished copy image data to buffer
    //LATBbits.LATB15 = 1 ;
    ssd1306_SPI_display();

}
 */
void ssd1306_SPI_display(void) {

    uint16_t i = 0;

    if (SSH1103 == 1) {
        //1.3 Zoll OLED
        NOP();
        ssd1306_SPI_command(SH1106_SETLOWCOLUMN | 0x0); // low col = 0
        ssd1306_SPI_command(SH1106_SETHIGHCOLUMN | 0x0); // // hi col = 0 Column start address (0 = reset)
        ssd1306_SPI_command(SH1106_SETSTARTLINE | 0x0); // line #0

        uint8_t height = 64;
        uint8_t width = 132;
        uint8_t m_row = 0;
        uint8_t m_col = 2;
        height >>= 3; //8
        width >>= 3; //16
        //unfinished !! 2018 bugs display interleved!!! 2018.7.10
        uint8_t p, j, k = 0;
        //for (p = 0; p < 8; i++) {
        //total 1024 times SPI2_Exchange8bit()
        for (p = 0; p < height; p++) {
            // send a bunch of data in one transmission
            ssd1306_SPI_command(0xB0 + p + m_row); //set page address  0xB0 =176
            ssd1306_SPI_command(m_col & 0xf); //set lower column address  start from third line pixel buffer
            ssd1306_SPI_command(0x10 | (m_col >> 4)); //set higher column address

            for (j = 0; j < 8; j++) {
                // SPI
                // for (k = 0; k < 16; k++, i++) {
                NOP();
                //__delay_us(1);
                LATBbits.LATB15 = 1; //D/C#
                NOP();
                for (k = 0; k < width; k++) {
                    SPI2_Exchange8bit(FC_buffer[i]);
                    i++;
                }

            }
        }
    } else { //0.96 OLED
        // SPI
        LATBbits.LATB15 = 0; //D/C#
        ssd1306_SPI_command(SSD1306_COLUMNADDR);
        ssd1306_SPI_command(0); // Column start address (0 = reset)
        ssd1306_SPI_command(SSD1306_LCDWIDTH - 1); // Column end address (127 = reset)

        ssd1306_SPI_command(SSD1306_PAGEADDR);
        ssd1306_SPI_command(0); // Page start address (0 = reset)
#if SSD1306_LCDHEIGHT == 64
        ssd1306_SPI_command(7); // Page end address
#endif
#if SSD1306_LCDHEIGHT == 32
        ssd1306_SPI_command(3); // Page end address
#endif
#if SSD1306_LCDHEIGHT == 16
        ssd1306_SPI_command(1); // Page end address
#endif
        NOP();
        __delay_us(1);
        LATBbits.LATB15 = 1; //D/C#
        //MSSP2_SPI_Exchange8bit(0x10);
        //uint16_t i = 0;

        //total 1024 times SPI2_Exchange8bit()
        for (i = 0; i < (SSD1306_LCDWIDTH * SSD1306_LCDHEIGHT / 8); i++) {
            // MSSP2_SPI_Exchange8bit(buffer[i]);

            SPI2_Exchange8bit(FC_buffer[i]); //logo
            //NOP();
            //__delay_us(1);
        }
    }

}

void Adafruit_SH1106_invertDisplay(uint8_t i) {
    if (i) {
        ssd1306_command(SH1106_INVERTDISPLAY);
    } else {
        ssd1306_command(SH1106_NORMALDISPLAY);
    }
}

void set_font_size(char t) {

    OLED_FontSize = t;

}

void SSD1306_clearDisplay(void) {
    memset(FC_buffer, 0, (SSD1306_LCDWIDTH * SSD1306_LCDHEIGHT / 8));
}


// the most basic function, set a single pixel

void drawPixel(int16_t x, int16_t y, uint16_t color) {
    if ((x < 0) || (x >= SSD1306_LCDWIDTH) || (y < 0) || (y >= SSD1306_LCDHEIGHT))
        return;

    /*
    // check rotation, move pixel around if necessary
    switch (getRotation()) {
    case 1:
      ssd1306_swap(x, y);
      x = WIDTH - x - 1;
      break;
    case 2:
      x = WIDTH - x - 1;
      y = HEIGHT - y - 1;
      break;
    case 3:
      ssd1306_swap(x, y);
      y = HEIGHT - y - 1;
      break;
    }
     */


    // x is which column
    switch (color) {
        case WHITE: FC_buffer[x + (y / 8) * SSD1306_LCDWIDTH] |= (1 << (y & 7));
            break;
        case BLACK: FC_buffer[x + (y / 8) * SSD1306_LCDWIDTH] &= ~(1 << (y & 7));
            break;
        case INVERSE: FC_buffer[x + (y / 8) * SSD1306_LCDWIDTH] ^= (1 << (y & 7));
            break;
    }

}
// write to FC_buffer OLED display buf array

void OLED_char_0(char character, short x, short y) {
    short table_offset = (character - 0x20);
    short Pix_offset = y * 128 + x;
    if (Pix_offset > 1023) Pix_offset = 0;
    unsigned int i = 0;
    for (i = 0; i < 6; i++) FC_buffer[Pix_offset + i ] = F6x8[table_offset][i];

}

void OLED_char_1(char character, short x, short y) {

    short table_offset = 16 * (character - 0x20);
    short Pix_offset = y * 128 + x;
    if (Pix_offset > 1023) Pix_offset = 0;
    char i = 0;
    for (i = 0; i < 8; i++)
        FC_buffer[Pix_offset + i ] = F8X16[table_offset + i];
    for (i = 0; i < 8; i++)
        FC_buffer[Pix_offset + i + 128] = F8X16[table_offset + i + 8];
    //for (char i = 0; i < 8; i++) FC_buffer[512 ] = F6x8[16 + i];
    //for (char i = 0; i < 8; i++) FC_buffer[512 + i + 128] = F6x8[16 + i+8];

}

void OLED_string(char* str, short x, short y) {
    //x col position  0-127
    //y row position  0-7
    short pos = 0;
    char character = str[pos++];
    short startx = x;
    short starty = y;
    while (character != '\0') {
        //OLED_FontSize 1: large fonts, 0 small fonts
        if (OLED_FontSize) {
            if (startx >= 120) {
                starty++; //wrap around
                startx = 0;
            }
            OLED_char_1(character, startx, starty);
            startx += 8;
            character = str[pos++];

        } else {
            if (startx >= 122) {
                starty++; //wrap around
                startx = 0;
            }
            OLED_char_0(character, startx, starty);
            startx += 6;
            character = str[pos++];
        }
    }
}

void ssd1306_command(uint8_t c) {
    // SPI
    LATBbits.LATB15 = 0; //RB15  OLED  D/C#
    SPI2_Exchange8bit(c);
}
//---INA233---

//get current value in A
/*
uint16_t INA233_get_value(uint8_t reg) {
    writeBuffer[0] = reg;
    int16_t res = 0;
    uint8_t IIC_Timeout = 0;
    readBuffer[0] = 0;
    readBuffer[1] = 0;
    // write one byte to EEPROM (3 is the number of bytes to write)
    I2C1_MESSAGE_STATUS status;
    I2C1_MasterWrite(writeBuffer, 1, INA_add, &status); // uint8_t *pdata ---> writeBuffer
    while (status == I2C1_MESSAGE_PENDING) {
        __delay_us(1);
        if (IIC_Timeout == 255) {
            res = 0;
            return res;
            // break;
        } else
            IIC_Timeout++;
    }
    if (status == I2C1_MESSAGE_ADDRESS_NO_ACK) {
        res = 0;
        sprintf(tmp_string, "IIC NoACK!");
        OLED_string(tmp_string, 0, 6);
        ssd1306_SPI_display(); //draw
        // __delay_ms(500);
        //ssd1306_SPI_display(); //draw
        __delay_ms(200);
        return res;
    }

    if (reg == Energy_reg) {
        I2C1_MasterRead(readBuffer, 7, INA_add, &status);
        __delay_us(200);
        res = readBuffer[1]+ (readBuffer[2] << 8);

        return res;



    } else {
        I2C1_MasterRead(readBuffer, 2, INA_add, &status);
        __delay_us(120);
        res = readBuffer[0]+ (readBuffer[1] << 8);

        return res;
    }
}
 */
//user defined

void SPI_disable(void) {
    SPI2CON1bits.DISSCK = 0;
    SPI2CON1bits.DISSDO = 0;
}

void SPI_enable(void) {
    SPI2CON1bits.DISSDO = 1;
    SPI2CON1bits.DISSDO = 1;
}

void SPI1_disable(void) {
    SPI1STATbits.SPIEN = 0;
}

void SPI1_enable(void) {
    SPI1STATbits.SPIEN = 1;
}

void TN903_ACT(void) {
    LATAbits.LATA4 = 0;
    LATBbits.LATB4 = 0; //RB4  ACT pin
}

void TN903_ACT_Hi(void) {
    LATAbits.LATA4 = 1;
    LATBbits.LATB4 = 1; //RB4  ACT pin high
}

uint8_t SPI1_read(void) {
    //bug dead loop?
    uint8_t loop = 0;
    SPI1BUF = 0x00;
    while (!SPI1STATbits.SPIRBF) {
        loop++;
        if (loop > 10)
            break;
    }
    return SPI1BUF; //read a byte

}
//parse function

int8_t Parse_TN903_data(uint8_t *Rxbuf, uint8_t Taget_type, uint8_t Taget_type2, double *parsed_val) {

    //ret=1:  got T_object values;  ret=2: got Ambient/PCB local temp.  
    //ret=3: got emissivity index value, 0.95 by default
    uint8_t ret = 0;
    uint8_t tmp_L, tmp_H = 0;
    //uint8_t len = 5;
    //uint8_t tag = 0;
    uint16_t tmp = 0;
    //uint8_t numBytes = 0;
    float TT = 0;
    //tag = Taget_type;
    //len = (uint8_t) sizeof (Rxbuf); //bug?
    //tmp_H=Rxbuf[1];
    // tmp_L=Rxbuf[2];

    if (Rxbuf[0] == Taget_type) { //Match head flag
        tmp_H = Rxbuf[1];
        tmp_L = Rxbuf[2];
        tmp = (tmp_H << 8) + tmp_L;
        TT = tmp;
        TT = TT * 0.0625;
        // TT = TT/(float)16;
        TT = TT - 273.15;
        //conversion
        *parsed_val = TT; //bug??? why?
        //*parsed_val = tmp / 16 - 273.15; //"/" division calculation bug??!!
        //T_object = 3.15;
        ret = 1;
        //break; //jump out for
    } else if (Rxbuf[0] == Taget_type2) { //Match head flag
        //*parsed_val = tmp / 16 - 273.15; //"/" division calculation bug??!!
        //T_object = 3.15;
        tmp_H = Rxbuf[1];
        tmp_L = Rxbuf[2];
        tmp = (tmp_H << 8) + tmp_L;
        TT = tmp;
        TT = TT * 0.0625;
        // TT = TT/(float)16;
        TT = TT - 273.15;
        //conversion
        *parsed_val = TT; //bug??? why?
        //*parsed_val = tmp / 16 - 273.15; //"/" division calculation bug??!!
        //T_object = 3.15;
        ret = 2;
        //break; //jump out for
    } else if (Rxbuf[0] == Reg_Emissivity) { //Match head flag

        tmp_H = Rxbuf[1];
        //conversion
        *parsed_val = tmp_H; //bug??? why?  5F=95  --->0.95

        ret = 3;
        //break; //jump out for
    } else {
        ret = 0;
    }


    //    for (numBytes = 0; numBytes < len - 2; numBytes++) {
    //        if (Rxbuf[numBytes] == Taget_type) { //Match head flag
    //            tmp_H = Rxbuf[numBytes + 1];
    //            tmp_L = Rxbuf[numBytes + 2];
    //            tmp = (uint16_t) (tmp_H << 8) + tmp_L;
    //            //conversion
    //            *parsed_val = (double) tmp / 16 - 273.15;
    //            ret = 1;
    //            numBytes=len; 
    //            //break; //jump out for
    //        } else {
    //            ret = 0;
    //        }
    //    }
    return ret;

    //    if (ret)
    //        return ret;
    //    else
    //        return numBytes;

}

//bug?

//int8_t Parse_TN903_data_test(uint8_t *Rxbuf, uint8_t Taget_type, float *parsed_val) {
//
//    uint8_t tmp_L, tmp_H = 0;
//    //uint8_t len = 0;
//    //uint8_t tag = 0;
//    uint16_t tmp = 0;
//    //uint8_t numBytes = 0;
//    //tag = Taget_type;
//    //len = (uint8_t) sizeof (Rxbuf);
//
//    if (Rxbuf[0] == Taget_type) { //Match head flag
//        tmp_H = Rxbuf[1];
//        tmp_L = Rxbuf[2];
//        tmp = (uint16_t) (tmp_H << 8) + tmp_L;
//        //conversion
//        *parsed_val = (float) tmp / 16.0 - 273.15;
//
//    } else {
//
//        return 0;
//    }
//
//    return 1;
//
//}




//^^^^^^^^^^^^^^^^^^^^^^^^^BT 740**********************************

void BT740_startup(void) {

    char AT_CMD_buf[24];
    uint8_t idx = 0;
    uint8_t len = 0;
    if (BT_ECHO) {
    } else {
        sprintf(AT_CMD_buf, "ATE0\r");
        len = strlen(AT_CMD_buf); // to include <CR> \r symbol
        for (idx = 0; idx < len; idx++) {
            UART1_Write(AT_CMD_buf[idx]);
            while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
                // Wait for the tranmission to complete
            }
        }
        __delay_us(100);
    }
    memset(AT_CMD_buf, 0, 24 * sizeof (char));
    sprintf(AT_CMD_buf, "ATS9058=15\r"); // GPIO8 output indicate MP(1)/AT mode(0)  /OK!
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);


    //set GPIO 6 to DCD

    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9056=2\r"); // GPIO6 output (0 on reset)
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);

    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS619=64\r"); //GPIO6 mask put dec values to BT740 0x40=64
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);
    //set GPIO 6 to 1
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS620=64\r"); //GPIO6 value
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_ms(1);




}

void BT740_init(void) {

    char AT_CMD_buf[24];
    uint8_t idx = 0;
    uint8_t len = 0;
    if (BT_ECHO) {
    } else {
        sprintf(AT_CMD_buf, "ATE0\r");
        len = strlen(AT_CMD_buf); // to include <CR> \r symbol
        for (idx = 0; idx < len; idx++) {
            UART1_Write(AT_CMD_buf[idx]);
            while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
                // Wait for the tranmission to complete
            }
        }
        __delay_ms(1);
    }
    //__delay_ms(10);
    //    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    //    sprintf(AT_CMD_buf, " ATS9002=]\r"); //escape charac. bug?? //0x5D  error!??
    //    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    //    for (idx = 0; idx < len; idx++) {
    //        UART1_Write(AT_CMD_buf[idx]);
    //        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
    //            // Wait for the tranmission to complete
    //        }
    //    }
    //    __delay_ms(1);
    //    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    //    sprintf(AT_CMD_buf, "ATS9056=2\r"); //LED--GPIO6 output, def low mode   //OK!
    //    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    //    for (idx = 0; idx < len; idx++) {
    //        UART1_Write(AT_CMD_buf[idx]);
    //        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
    //            // Wait for the tranmission to complete
    //        }
    //    }
    //    __delay_ms(1);

    //no shown?
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9058=15\r"); // GPIO8 output indicate MP(1)/AT mode(0)  /OK!
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);


    //set GPIO 6 to DCD

    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9056=2\r"); // GPIO6 output (0 on reset)
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9055=2\r"); // GPIO6 output (0 on reset)
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9054=2\r"); // GPIO6 output (0 on reset)
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);

    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS653=6\r"); //GPIO6 map to DCD?
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }

    __delay_us(100);

    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS652=5\r"); //GPIO5 map to ?
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);

    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS651=4\r"); //GPIO4 map to ?
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_ms(1);


    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS619=64\r"); //GPIO6 mask put dec values to BT740 0x40=64
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_ms(1);
    //set GPIO 6 to 1
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS620=64\r"); //GPIO6 value
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_ms(1);
    //    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    //    sprintf(AT_CMD_buf, "ATS9056=11\r"); // GPIO6 output, DCD11 DTR 11// not working !!
    //    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    //    for (idx = 0; idx < len; idx++) {
    //        UART1_Write(AT_CMD_buf[idx]);
    //        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
    //            // Wait for the tranmission to complete
    //        }
    //    }
    //    __delay_ms(1);



    //not working: error code 46
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "AT+BTN=\"SmartDevice\"\r"); //set device name ok!  AT+BTN=" XXX" 
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_ms(1);
    //power saving and sniff mode config
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9073=2\r"); //N sniff mode 
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);
    //power saving and sniff mode config
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9074=2\r"); //T sniff mode 
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);
    //power saving and sniff mode config
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9075=80\r"); //M min sniff mode 
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_us(100);
    //power saving and sniff mode config
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9076=150\r"); //M max sniff mode 
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_ms(1);
    //power saving and sniff mode config end-------------




    //last init phase, auto accept connection and save to flash
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9014=1\r"); //Auto accept channel for SPP
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    __delay_ms(1);
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "AT&W\r"); //Save paras to flash
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 24 * sizeof (uint8_t));
    __delay_ms(5);
}

void BT740_status_get(void) {

    char AT_CMD_buf[16];
    char BT740_Ant_buf[16];
    uint8_t idx = 0;
    uint8_t len = 0;


    sprintf(AT_CMD_buf, "ATI42\r"); // current module status
    len = strlen(AT_CMD_buf) + 1; // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 16 * sizeof (uint8_t));
    idx = 0;
    if (UART1_RX_cnt >= 1) {
        do {

            if (UART1_RX_DATA_AVAILABLE & UART1_StatusGet()) {
                BT740_Ant_buf[idx] = UART1_Read();
                idx++;
            }

        } while (idx < UART1_RX_cnt);
        // process BT740_Ant_buf data?
        //judge connection status



    }
}

void BT740_T_data_send(int T) {

    char Data_buf[16];
    uint8_t idx = 0;
    uint8_t len = 0;
    //sprintf(Data_buf, "35.6\r");
    sprintf(Data_buf, "%4d\r", T);
    //sprintf(Data_buf, "T_O:%5.1f ", (double)35.6);
    //sprintf(Data_buf, "%4.1f \r",T);  bug?
    len = strlen(Data_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(Data_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }

}

void U1RX_interrupt_EN(void) {

    IEC0bits.U1RXIE = 1;

} // 1 EN  IEC0bits.U1RXIE = 1;  /

void U1RX_interrupt_disable(void) {

    IEC0bits.U1RXIE = 0;

} // 1 EN  IEC0bits.U1RXIE = 0;  /


//iic sample code
/*
;************************************************************************
;* Bluetooth modul initialisieren										*
;************************************************************************
btminit
    call	pause

;ATS506=1
;ATE0   Disable Echo @ 0
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x45	;E
    movwf	TXREG
    call	fertig
    movlw	0x30	;0
    movwf	TXREG
    call	fertig
    movlw	0x0D    ;CR
    movwf	TXREG
    call	fertig
;	call	okay

    movlw	0x41		;AT+BTK="1234"
    movwf	TXREG
    call	fertig
    movlw	0x54
    movwf	TXREG
    call	fertig	
    movlw	0x2B
    movwf	TXREG
    call	fertig
    movlw	0x42
    movwf	TXREG
    call	fertig
    movlw	0x54
    movwf	TXREG
    call	fertig
    movlw	0x4B
    movwf	TXREG
    call	fertig
    movlw	0x3D ;=
    movwf	TXREG
    call	fertig
    movlw	0x22 ;"
    movwf	TXREG
    call	fertig
    movlw	0x31
    movwf	TXREG
    call	fertig
    movlw	0x32
    movwf	TXREG
    call	fertig
    movlw	0x33
    movwf	TXREG
    call	fertig
    movlw	0x34
    movwf	TXREG
    call	fertig
    movlw	0x22
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay
;ATS0=1
;Number of RING indications before automatically answering an incoming connection.
; A value of 0 disables autoanswer. -1..15
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x30	;0
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x31	;1
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay
;ATS512=4  Specify power up state.
;When set to 4, it is connectable and discoverable, e.g. AT+BTP.
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x31	;1
    movwf	TXREG
    call	fertig
    movlw	0x32	;2
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x34	;4
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

;ATS533=0  If set to 1, then GPIO5 follows RI state.
;If set to 2 then it follows the state of DSR.
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x30	;0
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay
;ATS534=2   LED blinks when not connected, right LED follows DCD state
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x34	;4
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x32	;2
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay
;ATS535=5  Link Supervision Timeout.
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

;ATS538=1  If 1, then when a successful pairing occurs,
;it automatically saves in the trusted device database ? if it has room to store it.
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x38	;8
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x31	;1
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

;AT&W  save to Non-volatile Memory
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x26	;&
    movwf	TXREG
    call	fertig
    movlw	0x57	;W
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

;ATZ Hardware Reset and emerge into mode ?n?
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x5A	;Z
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

btminitend
 */
// End of File

