/******************************************************************************/
/*smart device demo pcb 1.0 TN903`BT740 control PIC24fv32KA302     */
//while loop processing time about 16.88 ms
//SPI 1MHZ, IIC 340KHz@ BRG=0x25
/*Absolute Resolution 0.25mA @ 10mOhm Resistor */
/* fixed 1.25mV per LSB for V bus*/
//Assumg  MAX 65.536A, current_LSB = 2mA/LSB, CAL 2560
//2018.4.10 V2.0  FPS change mode mah mws improve ok 
//2018.4.10 V1.1  float display ok 
//*2018.3.26 V1.0  all function ok, to add Energy mode, mwh  mah function
/* 2018.3.6 v0.5
 * PIC sys CLK 32MHZ?8Mhz + PLL?, IIC 357Khz @ SSPADD= 0x27? PIN CLKO 16Mhz
 * INA233 400Khz IIC       slave   address     (0x40) ox80     LSB--MSB
 *Shunt voltage input range ?81.92 to 81.9175 mV 2.5uV/bit
 *fixed 1.25mV per LSB for V bus
 * 2.5mA /LSB @ 1mOhm shunt current resistor1
 * 1.1ms for both convertion time, Average = 4
 * spi 1mHz FOR OLED Driving, idle high active low mode 3
 *MCP9808 temp. sensor address 0011A2A1A0=  0011000  0x18<<1  0x30  ; MSB--LSB
 *TA: AMBIENT TEMPERATURE REGISTER (? ADDRESS ?0000 0101?b) 
 Temperature res 0.0625 degree/LSB   */
/******************************************************************************/


/* PIC24FV16KM202 INA233 OLED board,
 * IIC1: SDA1/SCL1 ---> INA233
 * SPI2: SCD2/SDO2 ---> OLED
 * SPI mode 3 SCK idle high,
 * File:   mainXC16.c
 * V1.0, need to improve freq, ID mode
 * Author: ZL
 * Achtung: #define UART1_CONFIG_RX_BYTEQ_LENGTH 1   reffers to uart receive buffer!
/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using MPLAB(c) Code Configurator

 */

//----------pin--------------------
//RA0 pin2  AN0  -- ws2812 light_sda
//RA1 pin3  LED indication , flashes
//RB2 pin6  UART1 RX
//RB3 pin7  AN5 V_akku
//RB4 pin11 TN903 ACT
//RB5 Pin14 SCK2  (SPI))  OLED
//RB6 Pin15 SDO2  (SPI))   OLED
//RB7 pin16  UART1 TX
//RB8 pin17  UART1 CTS
//RB9 pin18  UART1 RTS  output
//RB10 Pin21 SDI1
//RB11 pin22 SCK1
//RB12 pin23 AN12
//RB14 pin25  EXRNT1 ,(RTCC) NT1 key inputs(motor trigger) with ADC sampling key voltage, rise must > 2.2V
//---OLED SPI interface------------
//RB15  OLED  D/C#
//SCK2 SPI2
//reset OLED
//     LATAbits.LATA4 = 1;
//    LATAbits.LATA3 = 1;
//---OLED SPI interface end----------
//~~~~~~~~~~~~~~~~~RGB LED WS2812!!!!!!!!!!!!!!!!!!!!!!!!!!!!!--------
// Light_SDA  LATAbits.LATA0

#define SYS_FREQ         32000000L
#define FCY   SYS_FREQ/2
#define Reset() __asm__ volatile ("reset")
#define  NOP()  __asm__ volatile ("nop")


#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/adc1.h"
#include <stdlib.h>      //Data Conversion Functions
#include <string.h>   // memset
#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */
#include <stdio.h>
#include <libpic30.h>  //delay us
#include "oled_driver/Adafruit_SSD1306.h" //FC buffer
#include "oled_driver/oledfont.h"
//#include "WS2812_head.h"

//------------------OLED ---------------
//SPI SCK SDO
//RA3 reset
//RB15 C/D signal
uint8_t SSH1103 = 1; // 0 . ssd1306 driver;  1, ssh1103 driver  bigger OLED
//----------------TN903----------------
//RB4 pin11 TN903 ACT
//SPI1 slave mode 3 
uint8_t SPI1_buf[8]; //store tmp data from sensor
float T_object = 0;
float T_PCB = 0;
int8_t T_limit_H = 70;
int8_t T_limit_L = 0;
int8_t T_limit_Critical = 90;
uint8_t SPI1_buf_full = 0;
uint8_t SPI1_buf_len = 5;
uint8_t SPI1_read(void);
void TN903_ACT(void);
void TN903_ACT_Hi(void);
int8_t Reg_T_object = 0x4c;
int8_t Reg_T_Module = 0x66;
uint8_t Parse_T_object_data(uint8_t *Rxbuf, uint8_t Taget_type, float *parsed_val);

//-------------BT 740---------------------
unsigned char UART1_RX_cnt = 0;
void BT740_init(void);
//void BT740_T_data_send(double T);
void BT740_T_data_send(int T);
////----------------INA233----------------
//#define V_scale 4;
//#define V_scale2 10;
////&&&&&&&&&&&&&&&&&&&$$$$$$$$***********MCP9808************************-
//uint16_t MCP9808 = 0x19; // INA233 PCB2 0x19
//uint8_t TA_reg = 0x05; //AMBIENT TEMPERATURE REGISTER; bit 12 SIGN bit  0 @>0degree
//uint8_t mcp_temp_H = 0; //upper bits
//uint8_t mcp_temp_L = 0;
//double Temperature = 0;
//int8_t T_limit_H = 40;
//int8_t T_limit_L = 5;
//int8_t T_limit_Critical = 50;


//----------------IIC-----------------------
//#define SLAVE_I2C_GENERIC_RETRY_MAX           6
//#define SLAVE_I2C_GENERIC_DEVICE_TIMEOUT      3   // define slave timeout
//uint16_t INA233_get_value(uint8_t reg);

//----------------LED SSR Pin ---------------
#define LED_ON()  LATAbits.LATA1=1
#define LED_OFF()  LATAbits.LATA1=0
//#define SSR_ON() LATAbits.LATA0 = 1 //SSR high alarm
//#define SSR_OFF() LATAbits.LATA0 = 0 //SSR OFF
//----------------RGB LED number ---------------
//RB8-11: sig 1-4
uint8_t RGB_LED_mode = 24;

//=======================OLED=================
unsigned char SPI_mode_OLED = 1; //SPI mode using SPI2
void OLED_init(void);
void drawPixel(int16_t x, int16_t y, uint16_t color);
void SPI_disable(void);
void SPI_enable(void);
void ssd1306_SPI_display(void);
//void ssd1306_SPI_LOGO_display(void);
void ssd1306_SPI_DrawLine(uint8_t ln);
//void ssd1306_SPI_DrawLine1(void);
void ssd1306_command(uint8_t c);
void ssd1306_data(uint8_t c);
void ssd1306_SPI_command(uint8_t c);
void SSD1306_clearDisplay(void);
//void buffer_fill_char(void);
void OLED_string(char* str, short x, short y);
char OLED_FontSize = 0; // 0 for small size
void set_font_size(char t);


//---------------------ADC proto---------------
void ADC1_Disable(void);
void ADC1_Enable(void);
unsigned int adc_12bit(void);
unsigned int ADC_conversion = 0; //0-4095 Raw value
double Vref_ADC_BG = 2048; //2*Vbg  milli voltage @ 3.3V AVdd input; Band Gap Reference Voltage 1.024V
float Vref_ADC = 4096; //milli voltage


/////////////////////////////////////////////////////////////////////////
//uint8_t writeData;
//uint8_t readData;

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$   Globle control vars  $$$$$$$$$$$$$$$$$$$
//unsigned char slave_mode = 1;


///////////////
//unsigned char UART_INV = 0;

//unsigned char framed_data_SPI = 0; //spi
//unsigned char framed_data_UART = 1;

//uint8_t Frame_Head = 0x90; //Master Slave pair 0X90
//uint8_t  frame_head_ma = 0xFC; // send data to STM32 Master


//punsigned char sys_mode_master = 1; // master active sending RF
//unsigned char sys_mode_slave = 0; // slave active receiving RF
//uint8_t RF_heartbeat_EN =0; //test
unsigned char Sys_Frequncy = 32; //16Mhz or 4Mhz without PLL
#define CCP3PRL_default 0x400  //15.6KHz  0x400 1024
unsigned int Refresh_intval = 239; //ms    4fps 250
unsigned int Refresh_intval_s = 86; //ms   10 fps  100ms
unsigned int Refresh_intval_ss = 36; //ms   20fps   50ms
unsigned int fps_tmp = 4;


//---////////\\\\\\\\\\\\\------INA233*************************************************************/

/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/

char tmp_string[21];
unsigned int Refresh_intval_tmp = 0;

/*
                         Main application
 */
int main(void) {
    // initialize the device
    //char tmp_string[21];
    SYSTEM_Initialize();
    // ADC1_Initialize();
    //ADC_conversion = adc_12bit();
    Refresh_intval_tmp = Refresh_intval;
    LED_ON();
    //  LATAbits.LATA0 = 1; //SSR high alarm
    // __delay_ms(150);
    //LATAbits.LATA0 = 0; //SSR clear alarm

    OLED_init();
    __delay_ms(100);
    LED_OFF();
    SPI_enable(); //SPI2  oled
    ssd1306_SPI_display(); //display logo
    __delay_ms(1000);
    SSD1306_clearDisplay();
    //__delay_ms(10);
    //ssd1306_SPI_LOGO_display(); //display QR code logo
    __delay_ms(1000);
    SSD1306_clearDisplay();
    uint16_t cyc = 1;
    set_font_size(1);
    sprintf(tmp_string, "run!");
    OLED_string(tmp_string, 0, 0);

    ssd1306_SPI_display(); //draw
    __delay_ms(600);
    SSD1306_clearDisplay();
    uint8_t TN_flag = 0;
    uint8_t idx = 0;
    //RGB_LED_Reset();
    __delay_ms(100);
    

    OLED_string("SmartDevice", 0, 0);

    int8_t T_test = 0;
    TN903_ACT();
    uint16_t SPI1_cnt =0;
    SPI1_STATUS SPI1_status;

    while (1) {

        LED_ON();
        //TN903_ACT();
        //set_font_size(1);



        //test code========
        //T_test = SPI1_read(); //3.4 bug??

        //sprintf(tmp_string, "SPI:%X", T_test);
        //OLED_string(tmp_string, 0, 4);
        //=====================
        //----------phase 2-------BT SPP process

        BT740_T_data_send((int) 35.6); //test dummy date


        idx = 0;
        if (UART1_RX_cnt >= 1) {
            do {

                if (UART1_RX_DATA_AVAILABLE & UART1_StatusGet()) {
                    tmp_string[idx] = UART1_Read();
                    idx++;
                }

            } while (idx < UART1_RX_cnt);
        }
        // sprintf(tmp_string, "T:%5.1f ", 25);  //bug??
        sprintf(tmp_string, "SPI_cnt:%d ", (int8_t) SPI1_cnt);
        set_font_size(0);

        OLED_string(tmp_string, 0, 6);
        //------------phase 3 --------run time UI

        //counter = I2C1_ErrorCountGet();
        sprintf(tmp_string, "Run:%d", cyc);
        set_font_size(0);
        OLED_string(tmp_string, 0, 7);
        set_font_size(1);
        // ssd1306_SPI_display();


        if (cyc % 4 == 0) {
            //----------phase 1-------SPI TN903 read data routine---read interval?

           // do {
           //     T_test = SPI1_Exchange8bitBuffer(&SPI1_buf[T_test], SPI1_buf_len - T_test, &SPI1_buf[T_test]);

                // Do something else...

           // } while (T_test < SPI1_buf_len);


            // if (SPI1_buf_full) { //flag is always 0!
            for (idx = 0; idx < SPI1_buf_len; idx++) {
                //SPI1_Exchange8bitBuffer(0, 5, SPI1_buf); //not working
                if (SPI1STATbits.SRXMPT == false)   //Receive FIFO Empty bit 
                { SPI1_buf[idx] = SPI1_Exchange8bit (0); //bug?? first read OK!  working on!
                //SPI1_buf[idx] = SPI1_read(); //bug?
                SPI1_cnt++;
                
                }
            }
            SPI1_status= SPI1_StatusGet();
            
            SPI1_buf_full = 0;
            // }
           
            TN_flag = Parse_T_object_data(SPI1_buf, Reg_T_Module, &T_object); //PCB temp. 0x66
            //TN_flag = Parse_T_object_data(SPI1_buf, Reg_T_object, &T_object);   //  //Reg_T_object= 0x4c; 
            if (TN_flag)
                sprintf(tmp_string, "T%d:%4.1f ", TN_flag, (double) T_object);
            else sprintf(tmp_string, "T_O:ERR");
            //sprintf(tmp_string, "Run:%d,Er.%d ", cyc, counter);
            set_font_size(1);
            OLED_string(tmp_string, 0, 2);

            set_font_size(0);
            sprintf(tmp_string, "SPI:%X %X %X %X %X", SPI1_buf[0], SPI1_buf[1], SPI1_buf[2], SPI1_buf[3], SPI1_buf[4]);
            OLED_string(tmp_string, 0, 4);
            //            
            //            if (Power_mWh > 999)
            //                sprintf(tmp_string, "%dWh", (int) (Power_mWh / 1000.0));
            //            else sprintf(tmp_string, "%dmWh", (int) Power_mWh);
            //            OLED_string(tmp_string, 50, 0);
            //            //larger than 10mah, clear

            if (cyc > 65500) cyc = 0; //reset
            //            set_font_size(1);
        }
        ssd1306_SPI_display();


        LED_OFF();
        //TN903_ACT();

        // Add your application code

        __delay_ms(Refresh_intval_tmp);
        ClrWdt();
        cyc++;
        //RGB_LED_Reset();
    }// end of while

    return -1;
}

unsigned int adc_12bit(void) {
    //ADC1_ChannelSelect(ADC1_CHANNEL_AN15);//works
    //ADC1_ChannelSelect(ADC1_CHANNEL_AN10);
    //NOP();
    ADC1_Start();
    __delay_us(20);
    //for (int i = 0; i < 1000; i++) {
    //}
    ADC1_Stop();
    //__delay_us(18);
    //LATAbits.LATA1=0;
    //LATAbits.LATA1=1;
    //28uS
    unsigned int conversion = 0;

    while (!ADC1_IsConversionComplete()) {
        ADC1_Tasks();
    }
    conversion = ADC1_ConversionResultGet();
    return conversion; //12bit
}

void ADC1_Disable(void) {

    AD1CON1bits.ADON = 0;
}

void ADC1_Enable(void) {

    AD1CON1bits.ADON = 1;
}

//OLED display:

void OLED_init(void) {
    //init SSD1306 OLED
    LATAbits.LATA1 = 1; //led

    //reset
    LATAbits.LATA4 = 1; //unused for led
    LATAbits.LATA3 = 1; //working  oled reset
    __delay_ms(1);
    LATAbits.LATA4 = 0;
    LATAbits.LATA3 = 0;
    __delay_ms(100);
    LATAbits.LATA4 = 1;
    LATAbits.LATA3 = 1;
    __delay_us(20);
    SPI_enable();
    //uint8_t SPI_WriteBuffer[MY_BUFFER_SIZE];
    LATBbits.LATB15 = 0; //CD signal to low for cmd
    // Init sequence 1.3 or  0.96 OLED
    if (SSH1103 == 1) {//SSH1106

        ssd1306_command(SH1106_DISPLAYOFF); // 0xAE
        ssd1306_command(SH1106_SETDISPLAYCLOCKDIV); // 0xD5
        ssd1306_command(0x80); // the suggested ratio 0x80
        ssd1306_command(SH1106_SETMULTIPLEX); // 0xA8
        ssd1306_command(SSH1103_LCDHEIGHT - 1); //0x3F  63
        ssd1306_command(SH1106_SETDISPLAYOFFSET); // 0xD3
        ssd1306_command(0x00); // no offset

        ssd1306_command(SH1106_SETSTARTLINE | 0x0); // line #0 0x40
        ssd1306_command(SH1106_CHARGEPUMP); // 0x8D
        ssd1306_command(0x14); //vccstate
        ssd1306_command(SH1106_MEMORYMODE); // 0x20
        ssd1306_command(0x00); // 0x0 act like ks0108
        ssd1306_command(SH1106_SEGREMAP | 0x1);
        ssd1306_command(SH1106_COMSCANDEC);
        ssd1306_command(SH1106_SETCOMPINS); // 0xDA
        ssd1306_command(0x12);
        ssd1306_command(SH1106_SETCONTRAST);
        ssd1306_command(0xCF);
        ssd1306_command(SH1106_SETPRECHARGE); // 0xd9
        ssd1306_command(0xF1);
        ssd1306_command(SH1106_SETVCOMDETECT); // 0xDB
        ssd1306_command(0x40);
        ssd1306_command(SH1106_DISPLAYALLON_RESUME); // 0xA4
        ssd1306_command(SH1106_NORMALDISPLAY); // 0xA6
        //--turn on oled panel
        ssd1306_command(SH1106_DISPLAYON); //--turn on oled panel

    } else { //SSD1306
        ssd1306_command(SSD1306_DISPLAYOFF); // 0xAE
        ssd1306_command(SSD1306_SETDISPLAYCLOCKDIV); // 0xD5 ??
        ssd1306_command(0x80); // the suggested ratio 0x80

        ssd1306_command(SSD1306_SETMULTIPLEX); // 0xA8
        ssd1306_command(SSD1306_LCDHEIGHT - 1); //63   0x3F  diff to SSH1106

        ssd1306_command(SSD1306_SETDISPLAYOFFSET); // 0xD3
        ssd1306_command(0x0); // no offset
        ssd1306_command(SSD1306_SETSTARTLINE | 0x0); // line #0
        ssd1306_command(SSD1306_CHARGEPUMP); // 0x8D
        ssd1306_command(0x14);

        ssd1306_command(SSD1306_MEMORYMODE); // 0x20
        ssd1306_command(0x00); // 0x0 act like ks0108
        ssd1306_command(SSD1306_SEGREMAP | 0x1);
        ssd1306_command(SSD1306_COMSCANDEC);


        ssd1306_command(SSD1306_SETCOMPINS); // 0xDA   ??
        ssd1306_command(0x12);
        ssd1306_command(SSD1306_SETCONTRAST); // 0x81  ??
        ssd1306_command(0xCF);

        ssd1306_command(SSD1306_SETPRECHARGE); // 0xd9
        ssd1306_command(0xF1);
        ssd1306_command(SSD1306_SETVCOMDETECT); // 0xDB
        ssd1306_command(0x40);
        ssd1306_command(SSD1306_DISPLAYALLON_RESUME); // 0xA4
        ssd1306_command(SSD1306_NORMALDISPLAY); // 0xA6

        ssd1306_command(SSD1306_DEACTIVATE_SCROLL);

        //ssd1306_command(SH1106_DISPLAYALLON);
        ssd1306_command(SSD1306_DISPLAYON); //--turn on oled panel  0xA5  Entire Display ON
    }
    //SPI_disable();
}

void ssd1306_SPI_command(uint8_t c) {

    // SPI

    LATBbits.LATB15 = 0;
    SPI2_Exchange8bit(c);
    LATBbits.LATB15 = 1;
}

void ssd1306_Data(uint8_t c) {

    // SPI

    LATBbits.LATB15 = 1; //D/C# pin high
    SPI2_Exchange8bit(c);
    LATBbits.LATB15 = 1;
}

/*
void ssd1306_SPI_LOGO_display(void) {
    //need rewrite!
    uint16_t i = 0;
    uint16_t length = sizeof (FC_buffer);
    if (length >= sizeof (gImage_QR_logo)) {
        length = sizeof (gImage_QR_logo);
        for (i = 0; i < (length); i++) {
            FC_buffer[i] = gImage_QR_logo[i]; //logo
        }
    } else {
        length = sizeof (FC_buffer);
        for (i = 0; i < (length); i++) {

            FC_buffer[i] = gImage_QR_logo[i]; //logo

        }
    }

    //finished copy image data to buffer
    //LATBbits.LATB15 = 1 ;
    ssd1306_SPI_display();

}
 */
void ssd1306_SPI_display(void) {

    uint16_t i = 0;

    if (SSH1103 == 1) {
        //1.3 Zoll OLED
        NOP();
        ssd1306_SPI_command(SH1106_SETLOWCOLUMN | 0x0); // low col = 0
        ssd1306_SPI_command(SH1106_SETHIGHCOLUMN | 0x0); // // hi col = 0 Column start address (0 = reset)
        ssd1306_SPI_command(SH1106_SETSTARTLINE | 0x0); // line #0

        uint8_t height = 64;
        uint8_t width = 132;
        uint8_t m_row = 0;
        uint8_t m_col = 2;
        height >>= 3; //8
        width >>= 3; //16
        //unfinished !! 2018 bugs display interleved!!! 2018.7.10
        uint8_t p, j, k = 0;
        //for (p = 0; p < 8; i++) {
        //total 1024 times SPI2_Exchange8bit()
        for (p = 0; p < height; p++) {
            // send a bunch of data in one transmission
            ssd1306_SPI_command(0xB0 + p + m_row); //set page address  0xB0 =176
            ssd1306_SPI_command(m_col & 0xf); //set lower column address  start from third line pixel buffer
            ssd1306_SPI_command(0x10 | (m_col >> 4)); //set higher column address

            for (j = 0; j < 8; j++) {
                // SPI
                // for (k = 0; k < 16; k++, i++) {
                NOP();
                //__delay_us(1);
                LATBbits.LATB15 = 1; //D/C#
                NOP();
                for (k = 0; k < width; k++) {
                    SPI2_Exchange8bit(FC_buffer[i]);
                    i++;
                }

            }
        }
    } else { //0.96 OLED
        // SPI
        LATBbits.LATB15 = 0; //D/C#
        ssd1306_SPI_command(SSD1306_COLUMNADDR);
        ssd1306_SPI_command(0); // Column start address (0 = reset)
        ssd1306_SPI_command(SSD1306_LCDWIDTH - 1); // Column end address (127 = reset)

        ssd1306_SPI_command(SSD1306_PAGEADDR);
        ssd1306_SPI_command(0); // Page start address (0 = reset)
#if SSD1306_LCDHEIGHT == 64
        ssd1306_SPI_command(7); // Page end address
#endif
#if SSD1306_LCDHEIGHT == 32
        ssd1306_SPI_command(3); // Page end address
#endif
#if SSD1306_LCDHEIGHT == 16
        ssd1306_SPI_command(1); // Page end address
#endif
        NOP();
        __delay_us(1);
        LATBbits.LATB15 = 1; //D/C#
        //MSSP2_SPI_Exchange8bit(0x10);
        //uint16_t i = 0;

        //total 1024 times SPI2_Exchange8bit()
        for (i = 0; i < (SSD1306_LCDWIDTH * SSD1306_LCDHEIGHT / 8); i++) {
            // MSSP2_SPI_Exchange8bit(buffer[i]);

            SPI2_Exchange8bit(FC_buffer[i]); //logo
            //NOP();
            //__delay_us(1);
        }
    }

}

void Adafruit_SH1106_invertDisplay(uint8_t i) {
    if (i) {
        ssd1306_command(SH1106_INVERTDISPLAY);
    } else {
        ssd1306_command(SH1106_NORMALDISPLAY);
    }
}

void set_font_size(char t) {

    OLED_FontSize = t;

}

void SSD1306_clearDisplay(void) {
    memset(FC_buffer, 0, (SSD1306_LCDWIDTH * SSD1306_LCDHEIGHT / 8));
}


// the most basic function, set a single pixel

void drawPixel(int16_t x, int16_t y, uint16_t color) {
    if ((x < 0) || (x >= SSD1306_LCDWIDTH) || (y < 0) || (y >= SSD1306_LCDHEIGHT))
        return;

    /*
    // check rotation, move pixel around if necessary
    switch (getRotation()) {
    case 1:
      ssd1306_swap(x, y);
      x = WIDTH - x - 1;
      break;
    case 2:
      x = WIDTH - x - 1;
      y = HEIGHT - y - 1;
      break;
    case 3:
      ssd1306_swap(x, y);
      y = HEIGHT - y - 1;
      break;
    }
     */


    // x is which column
    switch (color) {
        case WHITE: FC_buffer[x + (y / 8) * SSD1306_LCDWIDTH] |= (1 << (y & 7));
            break;
        case BLACK: FC_buffer[x + (y / 8) * SSD1306_LCDWIDTH] &= ~(1 << (y & 7));
            break;
        case INVERSE: FC_buffer[x + (y / 8) * SSD1306_LCDWIDTH] ^= (1 << (y & 7));
            break;
    }

}
// write to FC_buffer OLED display buf array

void OLED_char_0(char character, short x, short y) {
    short table_offset = (character - 0x20);
    short Pix_offset = y * 128 + x;
    if (Pix_offset > 1023) Pix_offset = 0;
    unsigned int i = 0;
    for (i = 0; i < 6; i++) FC_buffer[Pix_offset + i ] = F6x8[table_offset][i];

}

void OLED_char_1(char character, short x, short y) {

    short table_offset = 16 * (character - 0x20);
    short Pix_offset = y * 128 + x;
    if (Pix_offset > 1023) Pix_offset = 0;
    char i = 0;
    for (i = 0; i < 8; i++)
        FC_buffer[Pix_offset + i ] = F8X16[table_offset + i];
    for (i = 0; i < 8; i++)
        FC_buffer[Pix_offset + i + 128] = F8X16[table_offset + i + 8];
    //for (char i = 0; i < 8; i++) FC_buffer[512 ] = F6x8[16 + i];
    //for (char i = 0; i < 8; i++) FC_buffer[512 + i + 128] = F6x8[16 + i+8];

}

void OLED_string(char* str, short x, short y) {
    //x col position  0-127
    //y row position  0-7
    short pos = 0;
    char character = str[pos++];
    short startx = x;
    short starty = y;
    while (character != '\0') {
        //OLED_FontSize 1: large fonts, 0 small fonts
        if (OLED_FontSize) {
            if (startx >= 120) {
                starty++; //wrap around
                startx = 0;
            }
            OLED_char_1(character, startx, starty);
            startx += 8;
            character = str[pos++];

        } else {
            if (startx >= 122) {
                starty++; //wrap around
                startx = 0;
            }
            OLED_char_0(character, startx, starty);
            startx += 6;
            character = str[pos++];
        }
    }
}

void ssd1306_command(uint8_t c) {
    // SPI
    LATBbits.LATB15 = 0; //RB15  OLED  D/C#
    SPI2_Exchange8bit(c);
}
//---INA233---

//get current value in A
/*
uint16_t INA233_get_value(uint8_t reg) {
    writeBuffer[0] = reg;
    int16_t res = 0;
    uint8_t IIC_Timeout = 0;
    readBuffer[0] = 0;
    readBuffer[1] = 0;
    // write one byte to EEPROM (3 is the number of bytes to write)
    I2C1_MESSAGE_STATUS status;
    I2C1_MasterWrite(writeBuffer, 1, INA_add, &status); // uint8_t *pdata ---> writeBuffer
    while (status == I2C1_MESSAGE_PENDING) {
        __delay_us(1);
        if (IIC_Timeout == 255) {
            res = 0;
            return res;
            // break;
        } else
            IIC_Timeout++;
    }
    if (status == I2C1_MESSAGE_ADDRESS_NO_ACK) {
        res = 0;
        sprintf(tmp_string, "IIC NoACK!");
        OLED_string(tmp_string, 0, 6);
        ssd1306_SPI_display(); //draw
        // __delay_ms(500);
        //ssd1306_SPI_display(); //draw
        __delay_ms(200);
        return res;
    }

    if (reg == Energy_reg) {
        I2C1_MasterRead(readBuffer, 7, INA_add, &status);
        __delay_us(200);
        res = readBuffer[1]+ (readBuffer[2] << 8);

        return res;



    } else {
        I2C1_MasterRead(readBuffer, 2, INA_add, &status);
        __delay_us(120);
        res = readBuffer[0]+ (readBuffer[1] << 8);

        return res;
    }
}
 */
//user defined

void SPI_disable(void) {
    SPI2CON1bits.DISSCK = 0;
    SPI2CON1bits.DISSDO = 0;
}

void SPI_enable(void) {
    SPI2CON1bits.DISSDO = 1;
    SPI2CON1bits.DISSDO = 1;
}

void SPI1_disable(void) {
    SPI1STATbits.SPIEN = 0;
}

void SPI1_enable(void) {
    SPI1STATbits.SPIEN = 1;
}

void TN903_ACT(void) {
    LATAbits.LATA4 = 0;
    LATBbits.LATB4 = 0; //RB4  ACT pin
}

void TN903_ACT_Hi(void) {
    LATAbits.LATA4 = 1;
    LATBbits.LATB4 = 1; //RB4  ACT pin high
}

uint8_t SPI1_read(void) {
    //bug dead loop?
    uint8_t loop = 0;
    SPI1BUF = 0x00;
    while (!SPI1STATbits.SPIRBF) {
        loop++;
        if (loop > 10)
            break;
    }
    return SPI1BUF; //read a byte

}
//parse function

uint8_t Parse_T_object_data(uint8_t *Rxbuf, uint8_t Taget_type, float *parsed_val) {

    uint8_t tmp_L, tmp_H = 0;
    uint8_t len = 0;
    //uint8_t tag = 0;
    uint16_t tmp = 0;
    uint8_t numBytes = 0;
    //tag = Taget_type;
    len = (uint8_t) sizeof (Rxbuf);

    for (numBytes = 0; numBytes < len - 2; numBytes++) {
        if (Rxbuf[numBytes] == Taget_type) { //Match head flag
            tmp_H = Rxbuf[numBytes + 1];
            tmp_L = Rxbuf[numBytes + 2];
            tmp = (uint16_t) (tmp_H << 8) + tmp_L;
            //conversion
            *parsed_val = (float) tmp / 16 - 273.15;
            break; //jump out for
        } else {
            tmp = 0;
            return 0;
        }
    }
    return 1;

}

void BT740_init(void) {

    char AT_CMD_buf[16];
    uint8_t idx = 0;
    uint8_t len = 0;
    sprintf(AT_CMD_buf, "ATE0\r");
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 16 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9002=^\r"); //escape charac.
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 16 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9056=2\r"); //LED--GPIO6 output, def low mode
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 16 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9058=15\r"); // GPIO8 output indicate MP(1)/AT mode(0)
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 16 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "AT+BTN=SmartDevice_BT740_Test\r"); //LED--GPIO6 output, def low mode
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 16 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "ATS9014=1\r"); //Auto accept channel for SPP
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 16 * sizeof (uint8_t));
    sprintf(AT_CMD_buf, "AT&W\r"); //Save paras to flash
    len = strlen(AT_CMD_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 16 * sizeof (uint8_t));

}

void BT740_status_get(void) {

    char AT_CMD_buf[16];
    char BT740_Ant_buf[16];
    uint8_t idx = 0;
    uint8_t len = 0;


    sprintf(AT_CMD_buf, "ATI42\r"); // current module status
    len = strlen(AT_CMD_buf) + 1; // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(AT_CMD_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }
    memset(AT_CMD_buf, 0, 16 * sizeof (uint8_t));
    idx = 0;
    if (UART1_RX_cnt >= 1) {
        do {

            if (UART1_RX_DATA_AVAILABLE & UART1_StatusGet()) {
                BT740_Ant_buf[idx] = UART1_Read();
                idx++;
            }

        } while (idx < UART1_RX_cnt);
        // process BT740_Ant_buf data?
        //judge connection status



    }
}

void BT740_T_data_send(int T) {

    char Data_buf[16];
    uint8_t idx = 0;
    uint8_t len = 0;
    //sprintf(Data_buf, "35.6\r");
    sprintf(Data_buf, "%4d\r", T);
    //sprintf(Data_buf, "T_O:%5.1f ", (double)35.6);
    //sprintf(Data_buf, "%4.1f \r",T);  bug?
    len = strlen(Data_buf); // to include <CR> \r symbol
    for (idx = 0; idx < len; idx++) {
        UART1_Write(Data_buf[idx]);
        while (!(UART1_StatusGet() & UART1_TX_COMPLETE)) {
            // Wait for the tranmission to complete
        }
    }

}







//iic sample code
/*
;************************************************************************
;* Bluetooth modul initialisieren										*
;************************************************************************
btminit
    call	pause

;ATS506=1
;ATE0   Disable Echo @ 0
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x45	;E
    movwf	TXREG
    call	fertig
    movlw	0x30	;0
    movwf	TXREG
    call	fertig
    movlw	0x0D    ;CR
    movwf	TXREG
    call	fertig
;	call	okay

    movlw	0x41		;AT+BTK="1234"
    movwf	TXREG
    call	fertig
    movlw	0x54
    movwf	TXREG
    call	fertig	
    movlw	0x2B
    movwf	TXREG
    call	fertig
    movlw	0x42
    movwf	TXREG
    call	fertig
    movlw	0x54
    movwf	TXREG
    call	fertig
    movlw	0x4B
    movwf	TXREG
    call	fertig
    movlw	0x3D ;=
    movwf	TXREG
    call	fertig
    movlw	0x22 ;"
    movwf	TXREG
    call	fertig
    movlw	0x31
    movwf	TXREG
    call	fertig
    movlw	0x32
    movwf	TXREG
    call	fertig
    movlw	0x33
    movwf	TXREG
    call	fertig
    movlw	0x34
    movwf	TXREG
    call	fertig
    movlw	0x22
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay
;ATS0=1
;Number of RING indications before automatically answering an incoming connection.
; A value of 0 disables autoanswer. -1..15
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x30	;0
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x31	;1
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay
;ATS512=4  Specify power up state.
;When set to 4, it is connectable and discoverable, e.g. AT+BTP.
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x31	;1
    movwf	TXREG
    call	fertig
    movlw	0x32	;2
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x34	;4
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

;ATS533=0  If set to 1, then GPIO5 follows RI state.
;If set to 2 then it follows the state of DSR.
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x30	;0
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay
;ATS534=2   LED blinks when not connected, right LED follows DCD state
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x34	;4
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x32	;2
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay
;ATS535=5  Link Supervision Timeout.
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

;ATS538=1  If 1, then when a successful pairing occurs,
;it automatically saves in the trusted device database ? if it has room to store it.
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x53	;S
    movwf	TXREG
    call	fertig
    movlw	0x35	;5
    movwf	TXREG
    call	fertig
    movlw	0x33	;3
    movwf	TXREG
    call	fertig
    movlw	0x38	;8
    movwf	TXREG
    call	fertig
    movlw	0x3D	;=
    movwf	TXREG
    call	fertig
    movlw	0x31	;1
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

;AT&W  save to Non-volatile Memory
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x26	;&
    movwf	TXREG
    call	fertig
    movlw	0x57	;W
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

;ATZ Hardware Reset and emerge into mode ?n?
    movlw	0x41	;A
    movwf	TXREG
    call	fertig
    movlw	0x54	;T
    movwf	TXREG
    call	fertig
    movlw	0x5A	;Z
    movwf	TXREG
    call	fertig
    movlw	0x0D
    movwf	TXREG
    call	fertig
    call	okay

btminitend
 */
// End of File

