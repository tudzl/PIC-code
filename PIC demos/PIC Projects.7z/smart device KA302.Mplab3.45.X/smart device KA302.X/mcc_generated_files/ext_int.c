/**
  EXT_INT Generated Driver File 

  @Company:
    Microchip Technology Inc.

  @File Name:
    ext_int.c

  @Summary
    This is the generated driver implementation file for the EXT_INT 
    driver using MPLAB(c) Code Configurator

  @Description:
    This source file provides implementations for driver APIs for EXT_INT. 
    Generation Information : 
        Product Revision  :  MPLAB(c) Code Configurator - pic24-dspic-pic32mm : v1.25
        Device            :  PIC24FV32KA302
        Driver Version    :  1.0
    The generated drivers are tested against the following:
        Compiler          :  XC16 1.26
        MPLAB             :  MPLAB X 3.45
 */

/**
   Section: Includes
 */
#include <xc.h>
#include <stdint.h>        /* For uint8_t definition */
#include "ext_int.h"
//***User Area Begin->code: Add External Interrupt handler specific headers 

//***User Area End->code: Add External Interrupt handler specific headers

/**
   Section: External Interrupt Handlers
 */
/**
  unsigned int Refresh_intval = 248; //ms    4fps 250
unsigned int Refresh_intval_s = 96; //ms   10 fps  100ms
unsigned int Refresh_intval_ss = 48; //ms   20fps   50ms
 */
extern unsigned char sleep_ENA ;
extern unsigned int Refresh_intval_tmp;
extern unsigned int Refresh_intval;
extern unsigned int Refresh_intval_s;
extern unsigned int Refresh_intval_ss;
extern unsigned int Refresh_intval_onesec;
extern unsigned int fps_tmp;
//extern uint8_t RGB_LED_mode;
//uint8_t led_mode_idx = 0;
//extern uint8_t BT_init;
//extern void BT740_init(void) ;
#define LED_ON()  LATAbits.LATA1=1
#define LED_OFF()  LATAbits.LATA1=0


//never entered?
/*
void __attribute__((interrupt, no_auto_psv)) _SPI1Interrupt(void) {
    //clear flag
    _SPI1IF=0;
    SPI1_buf_full +=1;  //buf full flag
    LED_ON();
    LED_OFF();
}
*/


void __attribute__((interrupt, no_auto_psv)) _INT1Interrupt(void) {
    //***User Area Begin->code: INT1 - External Interrupt 1***
    //switch refresh time  250ms  100ms  50ms
    sleep_ENA = 1-sleep_ENA;  //for test
    if (Refresh_intval_tmp == Refresh_intval) {
        Refresh_intval_tmp = Refresh_intval_s;
        fps_tmp = 10;
    } else if (Refresh_intval_tmp == Refresh_intval_s) {
        Refresh_intval_tmp = Refresh_intval_onesec;
        fps_tmp = 20;
        BT_init = 1 ;
    } else {
        Refresh_intval_tmp = Refresh_intval;
        fps_tmp = 4;
        //switch LED size

    }
    //***User Area End->code: INT1 - External Interrupt 1***
//    if (led_mode_idx == 12) RGB_LED_mode = 24;
//    else if (led_mode_idx == 24) {
//        RGB_LED_mode = 8;
//        led_mode_idx = 0;
//    }
//    led_mode_idx++;

    EX_INT1_InterruptFlagClear();
}
/**
    Section: External Interrupt Initializers
 */

/**
    void EXT_INT_Initialize(void)

    Initializer for the following external interrupts
    INT1
 */
void EXT_INT_Initialize(void) {
    /*******
     * INT1
     * Clear the interrupt flag
     * Set the external interrupt edge detect
     * Enable the interrupt, if enabled in the UI. 
     ********/
    EX_INT1_InterruptFlagClear();
    EX_INT1_PositiveEdgeSet();
    EX_INT1_InterruptEnable();
}
