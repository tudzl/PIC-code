//Touch panel TFT LCD test
//2018.1.23  CAP TP testing, retry later
//2017.12.08  ZL staubli HZ based on demo code 
//tested on 3.2zoll 320*240 LCD mit SD slot, ILI9341 + XPT2046
//PF15 T_PEN  INT
//PF14 T_CLK
//PF13 T_CS   RST
//PG0  SI
//PG1  SO   iiC  SPI£¿

#include "stdbool.h"
#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"	 
#include "24cxx.h"
#include "touch.h"
#include "WS2811_stm32.h"

//6 axel
#include "mpu6050.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h" 

u8 time=0;

char tmp_string[96];

void py_load_ui(u16 x,u16 y)
{	
	POINT_COLOR=BLUE;	
	LCD_ShowString(80,12,200,16,16,"MAIN MENU");		
	POINT_COLOR=RED;
	LCD_ShowString(80,32,200,16,16,"Touch panel");	
  LCD_ShowString(300,30,200,16,16,"LED Color");		
	POINT_COLOR=GRAY;
	LCD_DrawRectangle(60,60,190,120); //button frame top left
	LCD_DrawRectangle(60,150,190,210);	// top middle
	
	POINT_COLOR=RED;
	LCD_DrawRectangle(280,60,410,100);	// top right
  LCD_DrawRectangle(60,500,410,560);	// bot top  slide bar
	POINT_COLOR=RED;
	LCD_ShowString(320,70,200,16,16,"Red");	
	POINT_COLOR= DARKGREEN;
	LCD_DrawRectangle(280,130,410,170);	// top mid
	LCD_ShowString(320,140,200,16,16,"Green");
  POINT_COLOR=NEONGREEN;
	LCD_DrawRectangle(60,600,410,660);	
	
	POINT_COLOR=BLUE;	
	LCD_DrawRectangle(280,200,410,240);	// top bot
	LCD_ShowString(320,210,200,16,16,"Blue");	
	LCD_DrawRectangle(60,700,410,760);	
	
	POINT_COLOR=BLACK;	
	LCD_DrawRectangle(60,400,190,460);	//cycle RGB mode
	LCD_DrawRectangle(280,400,410,460);	//cycle RGB mode
	POINT_COLOR=PINK;
	LCD_ShowString(80,420,200,16,16,"Cycle Color");	
		
	POINT_COLOR=BRRED ;
	LCD_ShowString(300,420,200,16,16,"Exit Cycle");	
	POINT_COLOR=BLACK;
	
	LCD_ShowString(100,80,200,16,16,"VOLTAGE");	
	LCD_ShowString(100,170,200,16,16,"CURRENT");		 	 					   
}

int main(void)
{ 
	 bool Cycle_RGB_mode =false; 
	u8 idx=0;//,
	//u8 i=0;
	u32 R_tmp = 0;
  u32 G_tmp = 0;
  u32 B_tmp = 0;
	u32 slide_pos =0;
	u32 RGB_tmp =0;
	char lcd_id[12];	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//ÉèÖÃÏµÍ³ÖÐ¶ÏÓÅÏÈ¼¶·Ö×é2
	delay_init(168);    //³õÊ¼»¯ÑÓÊ±º¯Êý
	uart_init(115200);	//³õÊ¼»¯´®¿Ú²¨ÌØÂÊÎª115200
	LED_Init();					//³õÊ¼»¯LED 
 	LCD_Init();					//LCD³õÊ¼»¯ 
	KEY_Init(); 				//°´¼ü³õÊ¼»¯  
	WS2811_pin_Init();  //PF11 out
			LCD_Fill(00,00,480,800,LGRAYBLUE);//outline
  	LCD_Fill(10,10,470,790,LIGHTGRAY);//background
	
  POINT_COLOR=BLUE;//ÉèÖÃ×ÖÌåÎªÀ¶É«	   
	py_load_ui(60,60);
	
	tp_dev.init();
	LCD_ShowString(30,240,200,16,16,"Hint: please touch LCD");	
	// show lcddev.id;
	if (tp_dev.touchtype >=128)
	sprintf(lcd_id,"LCD_Dev:%04X  Type: Cap_TP",lcddev.id);//½«LCD ID´òÓ¡µ½lcd_idÊý×é¡£	
	else sprintf(lcd_id,"LCD_Dev:%04X  Type: Res_TP ",lcddev.id);//½«LCD ID´òÓ¡µ½lcd_idÊý×é¡£	
    POINT_COLOR = GRAY;
    LCD_ShowString(30, 300, 200, 16, 16, lcd_id);	
	  
	
	while(1) 
	{ 	
	tp_dev.scan(0);	 //u16 TP_Read_XOY(u8 xy)   tp_dev.x  tp_dev.y
		//u16 TP_Read_AD(u8 CMD)	 SPI read
	if(tp_dev.sta&TP_PRES_DOWN)			
	{			
      if(tp_dev.x[0]<lcddev.width&&tp_dev.y[0]<lcddev.height)
	  {
			POINT_COLOR=BLUE;	
			if(tp_dev.x[0]>60&&tp_dev.x[0]<190&&tp_dev.y[0]>60&&tp_dev.y[0]<120) //inside button box
		  LCD_ShowString(30,260,200,16,16,"Mode: Voltage");	
			else if(tp_dev.x[0]>60&&tp_dev.x[0]<190&&tp_dev.y[0]>150&&tp_dev.y[0]<210)	
		  LCD_ShowString(30,260,200,16,16,"Mode: Current"); 	
			else if (tp_dev.x[0]>280&&tp_dev.x[0]<410&&tp_dev.y[0]>60&&tp_dev.y[0]<100)	
		  {
				LCD_ShowString(30,260,200,16,16,"Mode: LED RED  "); 	
				 WS2811_send_color(LED_Red) ;
				
			}
				else if (tp_dev.x[0]>280&&tp_dev.x[0]<410&&tp_dev.y[0]>130&&tp_dev.y[0]<170)	
		  {
				LCD_ShowString(30,260,200,16,16,"Mode: LED Green "); 	
				 WS2811_send_color(LED_Green) ;
				
			}
			 else if (tp_dev.x[0]>280&&tp_dev.x[0]<410&&tp_dev.y[0]>200&&tp_dev.y[0]<240)	
		  {
				LCD_ShowString(30,260,200,16,16,"Mode: LED Blue  "); 	
				 WS2811_send_color(LED_Blue) ;
				
			}
			//slidebar_Red
			else if (tp_dev.x[0]>60&&tp_dev.x[0]<410&&tp_dev.y[0]>500&&tp_dev.y[0]<560)	
		  {
				 slide_pos =tp_dev.x[0];
				if(slide_pos<65)
				{ R_tmp = 0;
					slide_pos =66 ;
				}
				else if (slide_pos>405)
				{
					R_tmp = 255;
					slide_pos =404 ;
				}
				else R_tmp = (u32) ( (double) (slide_pos-60)*255.0/350.0  );
				//RGB_tmp = RGB_tmp&0x00ffff + (R_tmp<<16);
				RGB_tmp =  RGB_tmp&0x00ffff;
				RGB_tmp +=  R_tmp<<16;
				sprintf(tmp_string,"RGB RED  : %d Color: %x", R_tmp,RGB_tmp);//½«LCD ID´òÓ¡µ½lcd_idÊý×é¡£	
			  LCD_ShowString(240,260,200,16,16,tmp_string); 			
				LCD_Fill(slide_pos-5,502,slide_pos+5,558,LGRAYBLUE);
				LCD_Fill(61,502,slide_pos-5,558,LIGHTGRAY); //clear
				LCD_Fill(slide_pos+5,502,409,558,LIGHTGRAY); //clear
	
				
				WS2811_send_color(RGB_tmp) ;
				
			}
			//slidebar_Green
			else if (tp_dev.x[0]>60&&tp_dev.x[0]<410&&tp_dev.y[0]>600&&tp_dev.y[0]<660)	
		  {
				 slide_pos =tp_dev.x[0];
				if(slide_pos<65)
				{ G_tmp = 0;
					slide_pos =66 ;
				}
				else if (slide_pos>405)
				{
					G_tmp = 255;
					slide_pos =404 ;
				}
				else G_tmp = (u32) ( (double) (slide_pos-60)*255.0/350.0  );
				//RGB_tmp = RGB_tmp&0xff00ff + (G_tmp<<8);
				RGB_tmp =  RGB_tmp&0xff00ff;
				RGB_tmp +=  G_tmp<<8;
				sprintf(tmp_string,"RGB Green: %d Color: %x", G_tmp,RGB_tmp);//½«LCD ID´òÓ¡µ½lcd_idÊý×é¡£	
				LCD_ShowString(240,260,200,16,16,tmp_string); 	
				LCD_Fill(slide_pos-5,602,slide_pos+5,658,LGRAYBLUE);
				LCD_Fill(61,602,slide_pos-5,658,LIGHTGRAY); //clear
				LCD_Fill(slide_pos+5,602,409,658,LIGHTGRAY); //clear

				
				WS2811_send_color(RGB_tmp) ;
				
			}
			//slidebar_Blue
			else if (tp_dev.x[0]>60&&tp_dev.x[0]<410&&tp_dev.y[0]>700&&tp_dev.y[0]<760)	
		  {
				 slide_pos =tp_dev.x[0];
				if(slide_pos<65)
				{ B_tmp = 0;
					slide_pos =66 ;
				}
				else if (slide_pos>405)
				{
					B_tmp = 255;
					slide_pos =404 ;
				}
				else B_tmp = (u32) ( (double) (slide_pos-60)*255.0/350.0  );
				//RGB_tmp = RGB_tmp&0xff00ff + (G_tmp<<8);
				RGB_tmp =  RGB_tmp&0xffff00;
				RGB_tmp +=  B_tmp;
				sprintf(tmp_string,"RGB Blue : %d Color: %x", B_tmp,RGB_tmp);//½«LCD ID´òÓ¡µ½lcd_idÊý×é¡£	
				LCD_ShowString(240,260,200,16,16,tmp_string); 	
				LCD_Fill(slide_pos-5,702,slide_pos+5,758,LGRAYBLUE);
				LCD_Fill(61,702,slide_pos-5,758,LIGHTGRAY); //clear
				LCD_Fill(slide_pos+5,702,409,758,LIGHTGRAY); //clear

				
				WS2811_send_color(RGB_tmp) ;
				
			}
			//cycle color mode
			else  if (tp_dev.x[0]>60&&tp_dev.x[0]<190&&tp_dev.y[0]>400&&tp_dev.y[0]<460)	
			{
				Cycle_RGB_mode = true;

					POINT_COLOR=PINK;//ÉèÖÃ×ÖÌåÎªÀ¶É«	   
					LCD_ShowString(240,260,200,16,16,"Cycle color mode activated!"); 	
					RGB_LED_Reset();

				
				
				
		}
			else  if (tp_dev.x[0]>280&&tp_dev.x[0]<410&&tp_dev.y[0]>400&&tp_dev.y[0]<460)	
			{
				Cycle_RGB_mode = false ;
				RGB_LED_Reset();

					POINT_COLOR=BLUE;//ÉèÖÃ×ÖÌåÎªÀ¶É«	   
					LCD_ShowString(240,260,200,16,16,"Exit cycle color mode..."); 	


		}
			
			POINT_COLOR=BROWN ;	
			
			
			sprintf(tmp_string, "TP_inputs_X:%d  Y:%d ", tp_dev.x[0] , tp_dev.y[0]);
			LCD_ShowString(30,280,240,16,16,tmp_string); 	
			
	  
		}
	}
	else delay_ms(10);		 
		
	time++;
	
	
		if((time%10==0)&&(Cycle_RGB_mode)){
        cycle_color_function(1, idx);
			
			idx++;
			
			
			
  } 
	
	
	if(time%20==0)LED0=!LED0;
  } 
}


