/*============================================================================
Filename : touch.c
Project : QTouch Modular Library
Purpose : Provides Initialization, Processing and ISR handler of touch library,
          Simple API functions to get/set the key touch parameters from/to the
          touch library data structures

Usage License: Refer license.h file for license information
Support: Visit http://www.microchip.com/support/hottopics.aspx
               to create MySupport case.

------------------------------------------------------------------------------
Copyright (c) 2023 Microchip. All rights reserved.
------------------------------------------------------------------------------
============================================================================*/


#ifndef TOUCH_C
#define TOUCH_C

/*----------------------------------------------------------------------------
 *     include files
 *----------------------------------------------------------------------------*/

#include "touch.h"
#include "license.h"

#ifndef LOW_POWER_MODE
#define LOW_POWER_MODE 0u
#endif
/*----------------------------------------------------------------------------
 *   prototypes
 *----------------------------------------------------------------------------*/

/*! \brief configure keys, wheels and sliders.
 */
static touch_ret_t touch_sensors_config(void);

/*! \brief Touch Error callback function prototype.
 */
static void qtm_error_callback(uint8_t error);

static void data_stream(void);

/*----------------------------------------------------------------------------
 *     Global Variables
 *----------------------------------------------------------------------------*/

/* Flag to indicate time for touch measurement */
volatile uint8_t time_to_measure_touch_flag = 0;

/* Measurement Done Touch Flag  */
volatile uint8_t measurement_done_touch = 0;

/* Error Handling */
uint8_t module_error_code = 0;

/**********************************************************/
/******************* Acquisition Module *******************/
/**********************************************************/
#if     (DEF_NUM_CHANNELS == 1u)
its_acq_node_config_t its_node_config1[DEF_NUM_CHANNELS] = {
    NODE_0_PARAMS
};
#elif   (DEF_NUM_CHANNELS == 2u)
its_acq_node_config_t its_node_config1[DEF_NUM_CHANNELS] = {
    NODE_0_PARAMS,
    NODE_1_PARAMS
};
#elif   (DEF_NUM_CHANNELS == 3u)
its_acq_node_config_t its_node_config1[DEF_NUM_CHANNELS] = {
    NODE_0_PARAMS,
    NODE_1_PARAMS,
    NODE_2_PARAMS
};
#elif   (DEF_NUM_CHANNELS == 4u)
its_acq_node_config_t its_node_config1[DEF_NUM_CHANNELS] = {
    NODE_0_PARAMS,
    NODE_1_PARAMS,
    NODE_2_PARAMS,
    NODE_3_PARAMS
};
#else
#error "DEF_NUM_CHANNELS must be less than or equal to 4"
#endif

its_acq_set_config_t its_acq_set_config1 = {
    DEF_NUM_CHANNELS,
    &its_node_config1[0u],
    NUM_PULSES,
    PULSE_SETTING,
    SPREAD_SPECTRUM_ENABLE,
    FILTER_LEVEL
};

/* Node signal values */
its_acq_node_data_t its_node_stat1[DEF_NUM_CHANNELS];

its_acq_control_t its_acq_control1 = {
    &its_acq_set_config1, &its_node_stat1[0u]
};

/**********************************************************/
/*********************** Keys Module **********************/
/**********************************************************/

/* Keys set 1 - General settings */
qtm_touch_key_group_config_t qtlib_key_grp_config_set1 = {
    DEF_NUM_SENSORS,
    DEF_TOUCH_DET_INT,
    DEF_MAX_ON_DURATION,
    DEF_ANTI_TCH_DET_INT,
    DEF_ANTI_TCH_RECAL_THRSHLD,
    DEF_TCH_DRIFT_RATE,
    DEF_ANTI_TCH_DRIFT_RATE,
    DEF_TCH_DRIFT_STEP,
    DEF_DRIFT_HOLD_TIME,
    DEF_REBURST_MODE
};

qtm_touch_key_group_data_t qtlib_key_grp_data_set1;

/* Key data */
qtm_touch_key_data_t qtlib_key_data_set1[DEF_NUM_SENSORS];

/* Key Configurations */
#if     (DEF_NUM_SENSORS == 1u)
qtm_touch_key_config_t qtlib_key_configs_set1[DEF_NUM_SENSORS] = {
    KEY_0_PARAMS
};
#elif   (DEF_NUM_SENSORS == 2u)
qtm_touch_key_config_t qtlib_key_configs_set1[DEF_NUM_SENSORS] = {
    KEY_0_PARAMS,
    KEY_1_PARAMS
};
#elif   (DEF_NUM_SENSORS == 3u)
qtm_touch_key_config_t qtlib_key_configs_set1[DEF_NUM_SENSORS] = {
    KEY_0_PARAMS,
    KEY_1_PARAMS,
    KEY_2_PARAMS
};
#elif   (DEF_NUM_SENSORS == 4u)
qtm_touch_key_config_t qtlib_key_configs_set1[DEF_NUM_SENSORS] = {
    KEY_0_PARAMS,
    KEY_1_PARAMS,
    KEY_2_PARAMS,
    KEY_3_PARAMS
};
#endif

/* Container */
qtm_touch_key_control_t qtlib_key_set1
    = {&qtlib_key_grp_data_set1, &qtlib_key_grp_config_set1, &qtlib_key_data_set1[0], &qtlib_key_configs_set1[0]};


/*============================================================================
static touch_ret_t touch_sensors_config(void)
------------------------------------------------------------------------------
Purpose: Initialization of touch key sensors
Input  : none
Output : none
Notes  :
============================================================================*/
/* Touch sensors config - assign nodes to buttons / wheels / sliders / surfaces / water level / etc */
static touch_ret_t touch_sensors_config(void)
{
    uint8_t    sensor_nodes;
	touch_ret_t touch_ret = TOUCH_SUCCESS;
	
    qtm_its_init_measurement(&its_acq_control1);
        
	/* Enable sensor keys and assign nodes */
	for (sensor_nodes = 0u; sensor_nodes < DEF_NUM_CHANNELS; sensor_nodes++) {
		qtm_init_sensor_key(&qtlib_key_set1, sensor_nodes, &its_node_stat1[sensor_nodes]);
	}

	return (touch_ret);
}

static void touch_adc_config(void)
{
    /* ADC Configuration */
    ADCON1 = (0x80 | (ADC_CLOCK_SEL << 4));
}

#if (OVERSAMPLE_DELAY_US > 40u)
#define DELAY (OVERSAMPLE_DELAY_US - 40u)
#else
#define DELAY 0u
#endif

void sample_delay (void)
{
    __delay_us(DELAY);
}

/*============================================================================
static void qtm_error_callback(uint8_t error)
------------------------------------------------------------------------------
Purpose: this function is used to report error in the modules.
Input  : error code
Output : decoded module error code
Notes  :
Derived Module_error_codes:
    Acquisition module error =1
    post processing module1 error = 2
    post processing module2 error = 3
    ... and so on
============================================================================*/
static void qtm_error_callback(uint8_t error)
{
	module_error_code = error + 1u;
}

/*============================================================================
void touch_init(void)
------------------------------------------------------------------------------
Purpose: Initialization of touch library. PTC, timer, and
         datastreamer modules are initialized in this function.
Input  : none
Output : none
Notes  :
============================================================================*/
void touch_init(void)
{
    touch_adc_config();
    
    qtm_its_set_sample_delay_callback(&sample_delay);
    
	/* Configure touch sensors with Application specific settings */
	touch_sensors_config();
    
    touch_timer_config();
}

/*============================================================================
void touch_process(void)
------------------------------------------------------------------------------
Purpose: Main processing function of touch library. This function initiates the
         acquisition, calls post processing after the acquisition complete and
         sets the flag for next measurement based on the sensor status.
Input  : none
Output : none
Notes  :
============================================================================*/
void touch_process(void)
{
    uint8_t touch_ret = TOUCH_SUCCESS;
    
	/* check the time_to_measure_touch_flag flag for Touch Acquisition */
	if (time_to_measure_touch_flag == 1u) {
		        
		/* Clear the Measure request flag */
		time_to_measure_touch_flag = 0u;
		        
		/* disable interrupts */
        bool state = (bool)GIE;
        GIE = 0;
        
        /* measure sensors */
        qtm_its_measure_sensors();
        
        /* restore interrupt state */
        GIE = state;
        
		/* key module post-processing */
		touch_ret = qtm_key_sensors_process(&qtlib_key_set1);
        if (touch_ret != TOUCH_SUCCESS)
        {
            qtm_error_callback(1u);
        }

		/* handle re-burst requests from keys module */
		if ((0u != (qtlib_key_set1.qtm_touch_key_group_data->qtm_keys_status & QTM_KEY_REBURST))) {
			time_to_measure_touch_flag = 1u;
		} else {
			measurement_done_touch = 1u;
            
            #if ((LOW_POWER_MODE == 0u) && (DEF_TOUCH_DATA_STREAMER_ENABLE == 1u))
                        data_stream();
            #endif
		}
	}
}

static void data_stream(void)
{
    uint8_t sensor_node;
    uint16_t temp_sig, temp_ref;
    int16_t delta = 0u;
            
    EUSART1_Write(0xA5);
    for(sensor_node = 0u; sensor_node < DEF_NUM_SENSORS; sensor_node++)
    {   
        temp_sig = its_node_stat1[sensor_node].node_acq_signals;
        EUSART1_Write((uint8_t)(temp_sig & 0x00FFu));
        EUSART1_Write((uint8_t)(temp_sig >> 8));
        
        temp_ref = qtlib_key_set1.qtm_touch_key_data[sensor_node].channel_reference;
        EUSART1_Write((uint8_t)(temp_ref & 0x00FFu));
        EUSART1_Write((uint8_t)(temp_ref >> 8));
        
        delta = (int16_t)(temp_sig - temp_ref);
        EUSART1_Write((uint8_t)(delta & 0x00FF));
        EUSART1_Write((uint8_t)(delta >> 8));
        
        if (qtlib_key_set1.qtm_touch_key_data[sensor_node].sensor_state & KEY_TOUCHED_MASK)
        {
            EUSART1_Write(1u);
        }
        else
        {
            EUSART1_Write(0u);
        }
        
        EUSART1_Write(qtlib_key_set1.qtm_touch_key_config[sensor_node].channel_threshold);
    }
    EUSART1_Write(0x5A);
}

/*============================================================================
void touch_timer_handler(void)
------------------------------------------------------------------------------
Purpose: This function updates the time elapsed to the touch key module to
         synchronize the internal time counts used by the module.
Input  : none
Output : none
Notes  :
============================================================================*/
void touch_timer_handler()
{
    time_to_measure_touch_flag = 1u;
    qtm_update_qtlib_timer(DEF_TOUCH_MEASUREMENT_PERIOD_MS);
}

void touch_timer_config(void)
{  
    //TMR2_Period8BitSet(DEF_TOUCH_MEASUREMENT_PERIOD_MS);
    //TMR2_SetInterruptHandler(touch_timer_handler);
    //TMR2_StartTimer();
    TMR2_PeriodSet(DEF_TOUCH_MEASUREMENT_PERIOD_MS);
    TMR2_PeriodMatchCallbackRegister(touch_timer_handler);
    TMR2_Start();
}

uint16_t get_sensor_node_signal(uint16_t sensor_node)
{
	return (its_node_stat1[sensor_node].node_acq_signals);
}

void update_sensor_node_signal(uint16_t sensor_node, uint16_t new_signal)
{
	its_node_stat1[sensor_node].node_acq_signals = new_signal;
}

uint16_t get_sensor_node_reference(uint16_t sensor_node)
{
	return (qtlib_key_data_set1[sensor_node].channel_reference);
}

void update_sensor_node_reference(uint16_t sensor_node, uint16_t new_reference)
{
	qtlib_key_data_set1[sensor_node].channel_reference = new_reference;
}

uint8_t get_sensor_state(uint16_t sensor_node)
{
	return (qtlib_key_set1.qtm_touch_key_data[sensor_node].sensor_state);
}

void update_sensor_state(uint16_t sensor_node, uint8_t new_state)
{
	qtlib_key_set1.qtm_touch_key_data[sensor_node].sensor_state = new_state;
}

#endif /* TOUCH_C */
