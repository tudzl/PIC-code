/*============================================================================
Filename : touch.h
Project : QTouch Modular Library
Purpose : configuration macros for touch library

Usage License: Refer license.h file for license information
Support: Visit http://www.microchip.com/support/hottopics.aspx
               to create MySupport case.

------------------------------------------------------------------------------
Copyright (c) 2022 Microchip. All rights reserved.
------------------------------------------------------------------------------
============================================================================*/

#ifndef TOUCH_H
#define TOUCH_H

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/*----------------------------------------------------------------------------
 *     include files
 *----------------------------------------------------------------------------*/


#include "../mcc_generated_files/system/system.h"
#include "touch_api.h"
    
#define Extreme_low_power_EN 1u
/**********************************************************/
/******************* Acquisition controls *****************/
/**********************************************************/

/* Defines the system clock speed
 */
#if (_XTAL_FREQ == 32000000)
    #define SYS_CLOCK _32_MHZ
#else
#error "_XTAL_FREQ must be 32MHz for the PIC16F15244 ITS acq library"
#endif

/* Defines the Measurement Time in < 1.05 milli seconds >.
 * Range: 1 to 255.
 * Default value: 18 (roughly 20 milli seconds).
 */
#ifndef Extreme_low_power_EN
    #define DEF_TOUCH_MEASUREMENT_PERIOD_MS 18u
#else    
    #define DEF_TOUCH_MEASUREMENT_PERIOD_MS 56u
    #warning "_DEF_TOUCH_MEASUREMENT_PERIOD_MS about 60ms!"
#endif
/* Defines the number of pulses per measurement.
 * Recommended Range: 300 to 600.
 * Default value: 300.
 */
#define NUM_PULSES (uint16_t)600u

/* Defines the acquisition pulse setting.
 *  This parameter should be used for tuning the series R for each sensor.
 *  Once the series R has been tuned, PULSE_SETTING_1 should be used for best
 *  water rejection performance.
 * 
 * Range: (PULSE_SETTING_1 | PULSE_SETTING_2).
 * Default value: PULSE_SETTING_1.
 */
#define PULSE_SETTING         PULSE_SETTING_1

/* ADC Conversion Clock Options
 */
#define FOSC_DIV_2  0u
#define FOSC_DIV_4  4u
#define FOSC_DIV_8  1u
#define FOSC_DIV_16 5u
#define FOSC_DIV_32 2u
#define FOSC_DIV_64 6u

/* Defines the ADC clock divider setting.
 *  This parameter should be set based on the RC time constant of the sample
 *  capacitor and IO pin.
 */
#define ADC_CLOCK_SEL FOSC_DIV_32

/* Defines the delay in microseconds between samples. This applies to both
 *  over-samples when FILTER_LEVEL is greater than 1 and re-bursts triggered by
 *  the keys module. This parameter should be tuned based on the size of the
 *  largest sample capacitor used in the acquisition set. There must be enough
 *  delay so that the sample capacitor can fully discharge between samples.
 * 
 *  Note: The minimum delay between over-samples is 40us due to software
 *  execution time.
 */
#define OVERSAMPLE_DELAY_US 50u

/* Enables/disables spread spectrum acquisition, which is a noise countermeasure
 * Range: 0 or 1.
 * Default value: 1.
 */
#define SPREAD_SPECTRUM_ENABLE 1u

/* Defines the number of over-samples in each measurement.
 *  ITS is fundamentally different that PTC/CVD in the sense that oversampling
 *  is done in the analog domain by accumulating charge from many short pulses
 *  on the sample capacitor. More pulses provide higher SNR, but the sample
 *  capacitor must be tuned accordingly. The FILTER_LEVEL parameter for software
 *  oversampling has been included as a secondary option to provide flexibility
 *  when hardware modifications are troublesome.
 * 
 * Range: 1, 2, 4, 8, or 16.
 * Default value: 1.
 */
//#define FILTER_LEVEL FILTER_LEVEL_1
#define FILTER_LEVEL FILTER_LEVEL_2

/**********************************************************/
/******************** Node Parameters *********************/
/**********************************************************/

//#define DEF_NUM_CHANNELS (2u)
#define DEF_NUM_CHANNELS (1u)  //moorgen

/* ITS sensor pins must be on C port */
#define PIN_C0 0x01u
#define PIN_C1 0x02u
#define PIN_C2 0x04u
#define PIN_C3 0x08u
#define PIN_C4 0x10u
#define PIN_C5 0x20u
#define PIN_C6 0x40u
#define PIN_C7 0x80u

/* PORT C ADC channels on the PIC16F15244 */
#define ADC_CH_C2 0x12
#define ADC_CH_C3 0x13
#define ADC_CH_C4 0x14
#define ADC_CH_C5 0x15

/* Node Parameters 
 * {Sensor Pin, Sample Cap Pin, Sample Cap Pin ADC Channel, Digital Gain}
 * 
 * Digital Gain
 * Range: 1, 2, 4, 8, or 16 (must be less than or equal to the filter level)
 * Default value: 1.
 */
//#define NODE_0_PARAMS {PIN_C6, PIN_C3, ADC_CH_C3, GAIN_1}
    //#define NODE_0_PARAMS {PIN_C2, PIN_C3, ADC_CH_C3, GAIN_1}
#define NODE_0_PARAMS {PIN_C3, PIN_C2, ADC_CH_C2, GAIN_1}  //Moorgen
#define NODE_1_PARAMS {PIN_C4, PIN_C5, ADC_CH_C5, GAIN_1}

/**********************************************************/
/******************** Key Parameters **********************/
/**********************************************************/

/* Defines the number of key sensors
 * Range: 1 to 65535.
 * Default value: 1
 */
#define DEF_NUM_SENSORS (DEF_NUM_CHANNELS)

/* Defines Key Sensor setting
 * {Sensor Threshold, Sensor Hysteresis, Sensor AKS}
 */
#define KEY_0_PARAMS {30u, HYST_6_25, AKS_GROUP_1}   

#define KEY_1_PARAMS {20u, HYST_6_25, AKS_GROUP_1}  
//#define KEY_1_PARAMS {7u, HYST_12_5, AKS_GROUP_1}   

/* De-bounce counter for additional measurements to confirm touch detection
 * Range: 0 to 255.
 * Default value: 4.
 */
#define DEF_TOUCH_DET_INT 4

/* De-bounce counter for additional measurements to confirm away from touch signal
 * to initiate Away from touch re-calibration.
 * Range: 0 to 255.
 * Default value: 5.
 */
#define DEF_ANTI_TCH_DET_INT 5

/* Threshold beyond with automatic sensor re-calibration is initiated.
 * Range: RECAL_100/ RECAL_50 / RECAL_25 / RECAL_12_5 / RECAL_6_25 / MAX_RECAL
 * Default value: RECAL_100.
 */
#define DEF_ANTI_TCH_RECAL_THRSHLD RECAL_25 // def RECAL_25

/* Rate at which sensor reference value is adjusted towards sensor signal value
 * when signal value is greater than reference.
 * Units: 200ms
 * Range: 0-255
 * Default value: 20u = 4 seconds.
 */
#define DEF_TCH_DRIFT_RATE 5

/* Rate at which sensor reference value is adjusted towards sensor signal value
 * when signal value is less than reference.
 * Units: 200ms
 * Range: 0-255
 * Default value: 5u = 1 second.
 */
#define DEF_ANTI_TCH_DRIFT_RATE 1

/* Amount to drift each drift period.
 * Range: 1-10
 * Default value: 1u = 1 count per 200ms.
 */
#define DEF_TCH_DRIFT_STEP 1

/* Time to restrict drift on all sensor when one or more sensors are activated.
 * Units: 200ms
 * Range: 0-255
 * Default value: 20u = 4 seconds.
 */
#define DEF_DRIFT_HOLD_TIME 0

/* Set mode for additional sensor measurements based on touch activity.
 * Range: REBURST_NONE / REBURST_UNRESOLVED / REBURST_ALL
 * Default value: REBURST_UNRESOLVED
 */
#define DEF_REBURST_MODE REBURST_ALL

/* Sensor maximum ON duration upon touch.
 * Range: 0-255
 * Default value: 0
 */
//#define DEF_MAX_ON_DURATION 255
#define DEF_MAX_ON_DURATION 128//255
    

/**********************************************************/
/***************** Communication - Data Streamer ******************/
/**********************************************************/

#define DEF_TOUCH_DATA_STREAMER_ENABLE 1u

#ifdef __cplusplus
}
#endif // __cplusplus
#endif // TOUCH_C
