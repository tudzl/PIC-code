/*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
 */

/*
� [2024] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
 */
//This is a ITS water-resistant touch demo code for moorgen coaster application, by ZELL 
//need to adjust the touch parameters when the case is applied.
//Need to add breathing LED function
//V2.1GT modified to fit to v2 pcb, tested oK, sleep seems working, need test the power consumption!
//V0.7 added breathing effect functions, need further tests to optimize!
//V0.6 updated to ITS V1.4 lib from original V1.3 lib
//V0.5 added low power mode, improved debug printf , fixed ADC Vin Vbat calc errors
//V0.4 ITS touch works
//V0.3 added touch lib, need test
//V0.2 Key INT OK, RA5 PWM control based on TMR1/TMR2 need to improve!


//V0.1 basic function test OK, UART printf is OK, 19200 Baudrate
#include "mcc_generated_files/system/system.h"
#include <xc.h>
#include <string.h>
#include "touch/touch_api.h" 

/*
    Main application
 */

#define Debug_print_EN 0
uint8_t TMR_500ms_INT_flag = 0;
uint16_t V_bat_raw = 0;
uint16_t V_bat_mV = 0;
uint16_t V_in_raw = 0;
uint16_t V_in_mV = 0;
//uint8_t Light_ON_flg = 0 ;
uint8_t KEY_cnt = 0;
#define ADC_sample_scale 2
#define ADC_resolution 1024
#define Vin_offset 100
uint8_t run_cnt = 0;

uint16_t TMR1_INT_cnt = 0;
uint8_t Duty_high_flag = 0;


#define print_time_interval 2       

//#define Light_OFF_Timeout 100
#define sys_sleep_Timeout 10
extern qtm_touch_key_control_t qtlib_key_set1;
extern volatile uint8_t measurement_done_touch;
//#define LOW_POWER_MODE 0u
uint8_t Light_status = 0;
uint8_t Light_status_pre = 0;
//uint16_t Light_OFF_delay = 100;

uint8_t touch_cnt = 1;
uint8_t touch_filter_buf[4] = {0, 0, 0, 0};
uint8_t sys_active_countdown = 10;
//Breathing LED effect paras ; TMR1_250us, 8000 PER = 250uS, 31.25nS/cnt @ 32Mhz
uint8_t breath_start_flag = 0;
uint8_t LED_const_ON_flag = 0;
#define breath_step_total 5
#define Breath_duration 1000
uint8_t breath_onestep_length = Breath_duration;
uint8_t breath_step_idx = 0;
uint16_t Duty_high_buf[5] = {400, 800, 1600, 3200, 6400};
uint16_t Duty_low_buf[5] = {7600, 7200, 6400, 4800, 1600};

void LED_Init(void) {


    //test for moorgen V1 PCB
    //TRISAbits.TRISA0 = 0;
    TRISAbits.TRISA1 = 0; //Ring LEDs
   // LATAbits.LATA0 = 0;
    //V2 PCB
    TRISBbits.TRISB2 = 0;
    TRISBbits.TRISB3 = 0;
    LATBbits.LATB2 = 0;
}

void LED0_ON(void) {

    //LATAbits.LATA0 = 0; //moorgen
    //IO_RA0_WLED_SetLow();
    LATBbits.LATB2 = 0;
}

void LED0_OFF(void) {

    //LATAbits.LATA0 = 1; //moorgen
    //IO_RA0_WLED_SetHigh();
    LATBbits.LATB2 = 1;
}

void LED0_Toggle(void) {
    //IO_RA0_WLED_Toggle();
    LATBbits.LATB2 = ~LATBbits.LATB2;
    //LATAbits.LATA0 = 0; //moorgen
}


void Light_ON(void) {

    LATAbits.LATA1 = 1;
    LATBbits.LATB3 = 1;
}

void Light_OFF(void) {

    LATAbits.LATA1 = 0;
      LATBbits.LATB3 = 0;
}

void LED_Update(void) {
    uint8_t touch_valid = 0;
    uint8_t touch_res = 0;
    //Light_OFF_delay--;
    if (qtlib_key_set1.qtm_touch_key_data[0].sensor_state & KEY_TOUCHED_MASK) {

        LED0_ON();
        //Light_ON();
        touch_cnt++;
        touch_valid = 1;

    } else {
        LED0_OFF();
        //Light_OFF();
    }
    //    if (qtlib_key_set1.qtm_touch_key_data[1].sensor_state & KEY_TOUCHED_MASK){
    //        LED0_ON();
    //    }
    //    else LED0_OFF();
    //MA filter
    touch_filter_buf[0] = touch_filter_buf[1];
    touch_filter_buf[1] = touch_filter_buf[2];
    touch_filter_buf[2] = touch_filter_buf[3];
    touch_filter_buf[3] = touch_valid;

    touch_res = touch_filter_buf[0] + touch_filter_buf[1] + touch_filter_buf[2] + touch_filter_buf[3];
    if (3 < touch_res) {
        Light_status = 1 - Light_status;
        memset(&touch_filter_buf, 0, sizeof (touch_filter_buf));
        //Light_OFF_delay = Light_OFF_Timeout;
    }
    else if (1<touch_res){
        if (1==Light_status)
            Light_status = 0;
        
    }
    //     else if (0==Light_OFF_delay) {
    //         Light_status = 0;
    //         //Light_OFF_delay = 1;
    //     }

    //    if (0==touch_cnt%3){
    //        Light_status = 1-Light_status;
    //        touch_cnt = 1 ;
    //    }

    if (Light_status) {
        if (0 == Light_status_pre) {
            breath_start_flag = 1;
            TMR1_INT_cnt = 0;
            TMR1_Start();
        }
        if (LED_const_ON_flag) {
            Light_ON();

        }
        //TMR1_Start();
        //Light_ON(); //need to change to breathing effect
        sys_active_countdown = sys_sleep_Timeout;
    } else {
        if (1 == Light_status_pre) {
            LED_const_ON_flag = 0;
            Light_OFF();
            TMR1_Stop();
            sys_active_countdown = sys_sleep_Timeout+1;
        }
        //Light_OFF();
        //TMR1_Stop();
        breath_step_idx = 0;
    }
    Light_status_pre = Light_status;

}

void Breath_effect_process(void) {
    if (breath_start_flag) {
        //        if (breath_onestep_length > 0) {
        //            breath_onestep_length--;
        //        }
        //        if (0 == breath_onestep_length) {
        //
        //            breath_onestep_length = Breath_duration;
        //             breath_step_idx++;
        //
        //        }

        if (Breath_duration < TMR1_INT_cnt) {

            breath_step_idx++;
        }
        if ((breath_step_total - 1) == breath_step_idx) {
            //last step reached, disable breathing effect
            breath_start_flag = 0;
            breath_step_idx = 0;
            LED_const_ON_flag = 1;
            TMR1_Stop();
            TMR1_INT_cnt = 0;
        }


    }

}

#ifdef LOW_POWER_MODE
#warning #>>:low power mode(MCU sleep)enabled!
#endif

int main(void) {
    SYSTEM_Initialize();
    TMR1_Stop();
    LED_Init();
    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts 
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts 
    // Use the following macros to: 

    printf("MG Coaster V2 ITS touch test demo!");
    printf("-Version 2.1GT, 14.Dez.2024 by Zell-\r\n");
    printf("--FW code compiled: %s %s--\n", __DATE__, __TIME__);
    printf("---ITS Lib updated to V1.4 ---\r\n");
    uint16_t tmp_tmr_per = (uint16_t) TMR1_PeriodGet();
    uint16_t tmr1_per_us = tmp_tmr_per / 32;
    printf(">:Timer1 Per raw: %d; %d us\r\n", tmp_tmr_per, tmr1_per_us);
    touch_init();
    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts 
    //INTERRUPT_GlobalInterruptDisable(); 

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable();

    // Disable the Peripheral Interrupts 
    //INTERRUPT_PeripheralInterruptDisable(); 
    //Light_ON_flg = 0;

    while (1) {
        touch_process();

        if (measurement_done_touch) {
            LED_Update();
            Breath_effect_process();
        }



        if (TMR_500ms_INT_flag) {
            TMR_500ms_INT_flag = 0;


            if (0 == run_cnt % 2) {
                //IO_RA0_WLED_Toggle();
                V_in_raw = ADC_GetConversion(channel_ANA3_Vin);
                //V_in_raw = ADC_GetConversionResult();
                ADC_SelectChannel(channel_ANA2_Vbat);
                ADC_StartConversion();

            } else {
                V_bat_raw = ADC_GetConversionResult();
                //ADC_SelectChannel(channel_ANA3_Vin);
                //ADC_StartConversion();
            }

            if (0 == run_cnt % print_time_interval) {
                //IO_RA0_WLED_Toggle();
                LED0_ON();
                //V_in_mV = ADC_GetConversion(channel_ANA3_Vin);
                if (Debug_print_EN) {
                    printf(">>Vin raw:%d\r\n", V_in_raw);
                    //V_in_mV = V_in_raw * ADC_sample_scale;
                    V_in_mV = V_in_raw * 33 * ADC_sample_scale / 102; //3.3V AVDD, scaled to x100 = mV
                    //V_in_mV = V_in_mV / 1024;
                    V_in_mV = V_in_mV * 10+Vin_offset;
                    //V_in_mV = V_in_raw * ADC_sample_scale * 3300 / 1024; //issues in calc , wrong res, overflow 
                    printf("Vin:%d mV\r\n", V_in_mV);
                    //V_bat_mV = ADC_GetConversion(channel_ANA2_Vbat);
                    printf("V_akku R:%d\r\n", V_bat_raw);
                 
                    V_bat_mV = V_bat_raw * 33 * ADC_sample_scale / 102;
                   // V_bat_mV = V_bat_mV * ADC_sample_scale / 102 ; //1024->102
                    V_bat_mV =V_bat_mV*10;
                    printf("VAkku:%u mV\r\n", V_bat_mV);
                    if (Light_status) {
                         printf("!LED ON!\r\n");
                    }
                    
                    printf("cnt down:%d\r\n", sys_active_countdown);
                    if (3300 > V_bat_mV) {
                         printf(">>:Low Akku  sleep...\r\n");
                         SLEEP();
                    }
                    
                    
                    if (3 > sys_active_countdown) {
                         printf(">>:sleep proc...\r\n");
                         __delay_ms(10);
                    }
                    
                    
                    //ADC_StartConversion();
                    //ADC_SelectChannel
                    //printf("Key: %d\r\n", KEY_cnt);
                    //printf("TMR1_INT: %d\r\n", TMR1_INT_cnt);
                    //printf("DC_high: %d\r\n", Duty_high_flag);
                }
                else {
                    
                     V_bat_mV = V_bat_raw * 33 * ADC_sample_scale / 102;
                   // V_bat_mV = V_bat_mV * ADC_sample_scale / 102 ; //1024->102
                    V_bat_mV =V_bat_mV*10;
                    printf("VAkku:%u mV\r\n", V_bat_mV);
                    if (Light_status) {
                         printf("!LED ON!\r\n");
                    }
                    
                    printf("cnt down:%d\r\n", sys_active_countdown);
                    if (3300 > V_bat_mV) {
                         printf(">>:Low Akku  sleep...\r\n");
                         SLEEP();
                    }
                    
                    
                }

                LED0_OFF();
            }



            run_cnt++;
            if (0 < sys_active_countdown) {
                sys_active_countdown--;
            }
            CLRWDT();
        }


#if (LOW_POWER_MODE == 1u)
        if (0 == sys_active_countdown) {
            SLEEP();
            NOP();
        }
#endif    
    }
}


/*
 
ZZZZZ>>Vin raw: 540
Vin: 24 mV
V_akku raw: 24
VAkku: 26 mV
Key: 0
ZZZZZZZZ>>Vin raw: 24
Vin: 26 mV
V_akku raw: 540
VAkku: 24 mV
Key: 0
ZZZZZZZZZ>>Vin raw: 540
Vin: 24 mV
V_ak
 */