/* 
 * File:   newmain.c
 * Author: ling
 *
 * Created on July 18, 2017, 12:50 PM
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

