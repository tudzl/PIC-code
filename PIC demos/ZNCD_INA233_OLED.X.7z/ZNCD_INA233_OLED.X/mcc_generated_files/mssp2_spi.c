/**
  MSSP2_SPI Generated Driver API Header File

  @Company
    Microchip Technology Inc.

  @File Name
    mssp2_spi.c

  @Summary
    This is the generated source file for the MSSP2_SPI driver using MPLAB(c) Code Configurator

  @Description
    This source file provides APIs for driver for MSSP2_SPI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - pic24-dspic-pic32mm : v1.25
        Device            :  PIC24FV16KM202
        Driver Version    :  0.5
    The generated drivers are tested against the following:
        Compiler          :  XC16 1.26
        MPLAB 	          :  MPLAB X 3.45
*/

/*
    (c) 2016 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/

#include <xc.h>
#include "mssp2_spi.h"

/**
  Section: Driver Interface
*/


void MSSP2_SPI_Initialize (void)
{
    // SMP Middle; CKE Idle to Active; 
    SSP2STAT = 0x0000;
    // SSPEN enabled; WCOL no_collision; CKP Idle:High, Active:Low; SSPM FOSC/32; SSPOV no_overflow; 
    SSP2CON1 = 0x0032;
    // ACKEN disabled; GCEN disabled; PEN disabled; ACKDT acknowledge; RSEN disabled; RCEN disabled; SEN disabled; 
    SSP2CON2 = 0x0000;
    // SBCDE disabled; BOEN disabled; SCIE disabled; PCIE disabled; DHEN disabled; SDAHT 100ns; AHEN disabled; 
    SSP2CON3 = 0x0000;
    // AMSK 0; 
    SSP2MSK = 0x0000;
    // SSPADD 1; 
    SSP2ADD = 0x0001;
}

uint8_t MSSP2_SPI_Exchange8bit( uint8_t data )
{

    SSP2BUF = data;

    while (SSP2STATbits.BF == false)
    {

    }

    return SSP2BUF;
}

uint8_t MSSP2_SPI_Exchange8bitBuffer(uint8_t *dataTransmitted, uint8_t bufLen, uint8_t *dataReceived)
{
    uint16_t bytesWritten = 0;

    if(dataTransmitted != NULL)
    {
        if(dataReceived != NULL)
        {
            while(bytesWritten < bufLen )
            {
                dataReceived[bytesWritten] = MSSP2_SPI_Exchange8bit(dataTransmitted[bytesWritten]);
                bytesWritten++;
            }
        }else
        {
            while(bytesWritten < bufLen )
            {
                MSSP2_SPI_Exchange8bit(dataTransmitted[bytesWritten]);
                bytesWritten++;
            }
        }
    }
    else
    {
        if(dataReceived != NULL)
        {
            while(bytesWritten < bufLen )
            {
                dataReceived[bytesWritten] = MSSP2_SPI_Exchange8bit(MSSP2_SPI_DUMMY_DATA);
                bytesWritten++;
            }
        }
    }
    return bytesWritten;
}

bool MSSP2_SPI_IsBufferFull( void )
{ 
    return (!SSP2STATbits.BF);
}

bool MSSP2_SPI_HasWriteCollisionOccured( void )
{ 
    return (!SSP2CON1bits.WCOL);
}

bool MSSP2_SPI_HasReceiveOverflowOccured( void )
{ 
    return (!SSP2CON1bits.SSPOV);
}
//user defined
void SPI_disable(void) {
    SSP2CON1bits.SSPEN = 0;
}

void SPI_enable(void) {
    SSP2CON1bits.SSPEN = 1;
}

/**
 End of File
*/
