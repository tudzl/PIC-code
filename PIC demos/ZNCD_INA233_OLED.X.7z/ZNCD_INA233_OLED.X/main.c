/******************************************************************************/
/*PIC24fv16KM202  */
/*Absolute Resolution 0.25mA @ 10mOhm Resistor */
/* fixed 1.25mV per LSB for V bus*/
//Assumg  MAX 65.536A, current_LSB = 2mA/LSB, CAL 2560
//*2018.3.26 V1.0  all function ok, to add Energy mode, mwh  mah function
/* 2018.3.6 v0.5
 * PIC sys CLK 32MHZ?8Mhz + PLL?, IIC 357Khz @ SSPADD= 0x27? PIN CLKO 16Mhz
 * INA233 400Khz IIC       slave   address     (0x40) ox80     LSB--MSB
 *Shunt voltage input range ?81.92 to 81.9175 mV 2.5uV/bit
 *fixed 1.25mV per LSB for V bus
 * 2.5mA /LSB @ 1mOhm shunt current resistor1
 * 1.1ms for both convertion time, Average = 4
 * spi 1mHz FOR OLED Driving, idle high active low mode 3
 *MCP9808 temp. sensor address 0011A2A1A0=  0011000  0x18<<1  0x30  ; MSB--LSB
 *TA: AMBIENT TEMPERATURE REGISTER (? ADDRESS ?0000 0101?b) 
 Temperature res 0.0625 degree/LSB   */
/******************************************************************************/


/* PIC24FV16KM202 INA233 OLED board,
 * IIC1: SDA1/SCL1 ---> INA233
 * SPI2: SCD2/SDO2 ---> OLED
 * SPI mode 3 SCK idle high,
 * File:   mainXC16.c
 * V1.0, need to improve freq, ID mode
 * Author: ZL
 * Achtung: #define UART1_CONFIG_RX_BYTEQ_LENGTH 1   reffers to uart receive buffer!
/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using MPLAB(c) Code Configurator

 */

//----------pin--------------------
//RA0 pin2  ALARM SSR output! Alarm=high (Gate Cam control)
//RA1 pin3  LED indication , flashes
//RB2 pin6  UART1 RX
//RB3 pin7  GPIO out to loading table
//RB5 Pin14 SCK2  (SPI))
//RB6 Pin15 SDO2  (SPI))
//RB7 pin16 (INT0 )  UART1 TX
//RB8 pin17 Motor_LR_a
//RB9 pin18 Motor_LR_b
//RB10 Pin21 Motor_UD_a / HD24 up  triggered by INT1
//RB11 pin22 Motor_UD_b /HD24 down
//RB12 pin23 RF indication LED
//RB14 pin25  EXRNT1 ,(RTCC) NT1 key inputs(motor trigger) with ADC sampling key voltage, rise must > 2.2V
//---OLED SPI interface------------
//RB15  OLED  D/C#
//SCK2 SPI2
//reset OLED
//     LATAbits.LATA4 = 1;
//    LATAbits.LATA3 = 1;
//---OLED SPI interface end----------
//------Ultrasonic--------
//AN5 pin7 RB3 ADC  Battery voltage input ( 6V-8.4V  2:1 resistor scaling to <5V input) ultrasonic_1
//An11   RB13 ADC ultrasonic_2
//-------Ultrasonic end---------------
//Band Gap Reference Voltage, 1.024 V,  can set 2x/4x as V ref (should less than AVdd)
//ADC  1Tad = 1 us
//AN4 pin6 Vbat out
//AN5 pin7 RB3 ADC current sense signal / ultrasonic_1
//AN13 pin9 RA2 ADC Key input
//AN15 pin11 RB4 PWM poti input 0-5V
//AN16 pin12 RA4  Key ADC input
//An11   RB13 ultrasonic_2
//SCK2 Pin14,RB5 Digital
//SDO2 Pin15,RB6 Digital
//SDI2 pin19 RA7 Digital
//SS2  Pin23 Digital IC output
#define SYS_FREQ         32000000L
#define FCY   SYS_FREQ/2
#define Reset() __asm__ volatile ("reset")
#define  NOP()  __asm__ volatile ("nop")


#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/adc1.h"
#include <stdlib.h>      //Data Conversion Functions
#include <string.h>   // memset
#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */
#include <stdio.h>
#include <libpic30.h>  //delay us
#include "Adafruit_SSD1306.h" //FC buffer
#include "oledfont.h"
//----------------INA233----------------
#define V_scale 4;
#define V_scale2 10;
//&&&&&&&&&&&&&&&&&&&$$$$$$$$***********MCP9808************************-
uint16_t MCP9808 = 0x18; // INA233 PCB2 0x19
uint8_t TA_reg = 0x05; //AMBIENT TEMPERATURE REGISTER; bit 12 SIGN bit  0 @>0degree
uint8_t mcp_temp_H = 0; //upper bits
uint8_t mcp_temp_L = 0;
double Temperature = 0;
int8_t T_limit_H = 40;
int8_t T_limit_L = 5;
int8_t T_limit_Critical = 50;


//----------------IIC-----------------------
#define SLAVE_I2C_GENERIC_RETRY_MAX           6
#define SLAVE_I2C_GENERIC_DEVICE_TIMEOUT      3   // define slave timeout
uint16_t INA233_get_value(uint8_t reg);

//----------------LED SSR Pin ---------------
#define LED_ON()  LATAbits.LATA1=1
#define LED_OFF()  LATAbits.LATA1=0
#define SSR_ON() LATAbits.LATA0 = 1 //SSR high alarm
#define SSR_OFF() LATAbits.LATA0 = 0 //SSR OFF
//----------------I/O output Pin ---------------
//RB8-11: sig 1-4


//=======================OLED=================
void OLED_init(void);
void drawPixel(int16_t x, int16_t y, uint16_t color);

void SPI_disable(void);
void SPI_enable(void);
void ssd1306_SPI_display(void);
void ssd1306_SPI_DrawLine(uint8_t ln);
//void ssd1306_SPI_DrawLine1(void);
void ssd1306_command(uint8_t c);
void ssd1306_data(uint8_t c);
void ssd1306_SPI_command(uint8_t c);
void SSD1306_clearDisplay(void);
//void buffer_fill_char(void);
void OLED_string(char* str, short x, short y);
char OLED_FontSize = 0; // 0 for small size
void set_font_size(char t);


//---------------------ADC proto---------------
void ADC1_Disable(void);
void ADC1_Enable(void);
unsigned int adc_12bit(void);
unsigned int ADC_conversion = 0; //0-4095 Raw value


//////////////////////////--Ultrasonic--///////////////////////////////////////////
float US1 = 0;
//float US2 = 0;
//float US_thre = 200; //milli voltage
float Vref_ADC = 4096; //milli voltage
//bool Ultrasonic_safe = true;
//float REF_ADC=0 ;
//unsigned int adc_AN11_US1(void);

/////////////////////////////////////////////////////////////////////////
//uint8_t writeData;
//uint8_t readData;

//$$$$$$$$$$$$$$$$$$$$$$$$$$$$   Globle control vars  $$$$$$$$$$$$$$$$$$$
//unsigned char slave_mode = 1;
unsigned char SPI_mode_OLED = 1;

//unsigned char UART_receiver_mode = 1;
//unsigned char UART_Data_mode = 1; //2, pm2.5 sensor data;  default 1 send key value, 0 send PWM_DC test mode
//#define MY_BUFFER_SIZE 2
//#define MY_BUFFER_SIZE 8
//unsigned char UART1_RX_cnt = 0;
//uint8_t UART1_W_Buffer[MY_BUFFER_SIZE];
//uint8_t UART1_R_Buffer[MY_BUFFER_SIZE];

///////////////
//unsigned char UART_INV = 0;

unsigned char framed_data_SPI = 0; //spi
//unsigned char framed_data_UART = 1;

//uint8_t Frame_Head = 0x90; //Master Slave pair 0X90
//uint8_t  frame_head_ma = 0xFC; // send data to STM32 Master


//punsigned char sys_mode_master = 1; // master active sending RF
//unsigned char sys_mode_slave = 0; // slave active receiving RF
//uint8_t RF_heartbeat_EN =0; //test
unsigned char Sys_Frequncy = 32; //16Mhz or 4Mhz without PLL
#define CCP3PRL_default 0x400  //15.6KHz  0x400 1024
unsigned int Refresh_intval = 237; //ms

//---////////\\\\\\\\\\\\\------INA233*************************************************************/

/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/

//char result_buf[5]; // buf of results from sensor , to be displayed on LCD
//INA226/233 Reg address define
uint16_t INA_add = 0x40; //INA233 device address , iic <<1
uint16_t INA_add40 = 0x40; //INA233 device addressINA_add
uint8_t writeBuffer[3]; //IIC buffer
uint8_t readBuffer[8]; //IIC buffer
uint8_t tmp_H = 0; //upper bits
uint8_t tmp_L = 0;
//INA233   Reg Address
uint8_t MFR_CALIBRATION = 0xD4;
uint8_t MFR_ADC_CONFIG = 0xD0;
uint8_t Shunt_Voltage_reg = 0xD1; //original readings
uint8_t Bus_Voltage_reg = 0x88; //0h?7FFFh , 40.96V MAX
uint8_t Energy_reg = 0x86; //return 7 bytes
uint8_t Power_reg = 0x97;
uint8_t Current_reg = 0x89; //"READ_IN" shunt voltage value * CAL value 
uint8_t DEF_reg = 0x12;
uint8_t ClearF_reg = 0x3;

//unsigned char Calibration_Reg = 5;
//unsigned char Alert_Mask_Enable = 6; //The Mask/Enable Register selects the function that is enabled to control the Alert pin
//unsigned char Alert_Limit = 7; //set limit value
//char Die_ID = 0xFF;
//INA config paras
//unsigned char Alert_conf_L = 0b01000000; //V bus OVP
//unsigned char Alert_conf_H = 0b00010000; //AFF enable
//unsigned short conf1 = 0x4c07; //Configuration_Reg : Average 256, 140 us conversion times, continuous voltage+current.
//unsigned short conf2 = 0x4727; //Configuration_Reg : Average 64, 1.1mS conversion times, continuous voltage+current.
unsigned char conf_ADC_H = 0b01000011; // 1.1ms for both convertion time, Average = 4
unsigned char conf_ADC_L = 0b00100111;
//unsigned char conf3_H = 0b01000010; //Configuration_Reg : 4x Average , 140uS conversion times, continuous voltage+current.
//unsigned char conf3_L = 0b00000111;
//unsigned char conf4_H = 0b01000010; //Configuration_Reg : 4x Average , 200uS conversion times, continuous voltage+current.
//unsigned char conf4_L = 0b01001111;
//unsigned char cal_H = 0b00000100; //Calibration :   25mOhm
//unsigned char cal_L = 0b00000000; //2000DEC= 0b11111010000 ?  1000DEC= 1111101000 102DEC=1100110 1024DEC= 10000000000
//101000000000   2560dec   10mOhm   0.25mA resolution
uint16_t CAL = 2560; //CAL para 2mA, 1mOhm 
uint8_t I_scale = 2; //2mA/LSB
unsigned char cal_H = 0b00001010; //2560
unsigned char cal_L = 0b00000000;
int sign = 0;

/* i.e. uint8_t <variable_name>; */
uint8_t Vbus_limit = 36; // OVP alert Voltage in Volt
double Vbus = 0; // mV
double Vbus_volt = 0; // V
uint16_t Vbus_mili = 0; // mili part of Vbus
uint16_t Vbus_raw = 0;
uint16_t Power_raw = 0;
int16_t Current_mA = 0;
//float Current_mA_offset_correct1 = 0.99;
//float Current_mA_offset_correct2 = 0.979;
//float Current_mA_offset_correct3 = 0.977;
double Current_A = 0;
int Current_mili = 0;
double Power_W = 0;
double Power_mW = 0;
//energy
double Power_mWs = 0;
double Power_mWh = 0;
double Power_mAs = 0;
double Power_mAh = 0;

char tmp_string[21];

/*
                         Main application
 */
int main(void) {
    // initialize the device
    //char tmp_string[21];
    SYSTEM_Initialize();
    ADC1_Initialize();
    ADC_conversion = adc_12bit();
    unsigned Refresh_intval_tmp = Refresh_intval;
    LED_ON();
    LATAbits.LATA0 = 1;
    __delay_ms(100);
    LATAbits.LATA0 = 0;
    LED_OFF();
    OLED_init();
    __delay_ms(100);
    SPI_enable();
    ssd1306_SPI_display(); //display logo
    __delay_ms(1000);
    SSD1306_clearDisplay();



    if (SPI_mode_OLED) {
        SPI_enable();

        //if (ln >= 48) ln = 0;

        set_font_size(1);

        sprintf(tmp_string, "ZNCD INA TEST");
        OLED_string(tmp_string, 0, 0);

        ssd1306_SPI_display(); //draw
        __delay_ms(500);
    }

    // int numBytes = 0;

    unsigned int cyc = 1;
    //IIC init
    MSSP1_I2C_Initialize();
    uint8_t timeOut, slaveTimeOut; //IIC use
    uint16_t counter = 0;
    //MSSP1_I2C_MESSAGE_STATUS status ;
    MSSP1_I2C_MESSAGE_STATUS status = MSSP1_I2C_MESSAGE_PENDING;


    //INA233 init:
    sprintf(tmp_string, "INA inti...");
    OLED_string(tmp_string, 0, 6);
    ssd1306_SPI_display(); //draw
    __delay_ms(300);
    writeBuffer[0] = MFR_CALIBRATION; //reg address
    writeBuffer[1] = cal_L; //2560
    writeBuffer[2] = cal_H;
    slaveTimeOut = 0;
    timeOut = 0;

    //for (counter = 0; counter < nCount; counter++) {
    // while (status != MSSP1_I2C_MESSAGE_FAIL) {

    MSSP1_I2C_MasterWrite(writeBuffer, 3, INA_add, &status);
    // wait for the message to be sent or status has changed.
    while (status == MSSP1_I2C_MESSAGE_PENDING) {
        // add some delay here
        // __delau_us(1);
        // timeout checking
        // check for max retry and skip this byte
        //sprintf(tmp_string, "T:%d, C%d", slaveTimeOut, counter);
        //OLED_string(tmp_string, 0, 4);
        sprintf(tmp_string, "IIC pending");
        OLED_string(tmp_string, 0, 6);
        ssd1306_SPI_display(); //draw
        //__delay_ms(200);
        slaveTimeOut++;
        //counter++;
    }//end of while

    writeBuffer[0] = MFR_ADC_CONFIG; //reg address
    writeBuffer[1] = conf_ADC_L; //1.1ms  4 ave
    writeBuffer[2] = conf_ADC_H;
    MSSP1_I2C_MasterWrite(writeBuffer, 3, INA_add, &status);
    // wait for the message to be sent or status has changed.
    while (status == MSSP1_I2C_MESSAGE_PENDING) {
        // add some delay here
        __delay_us(1);
        // timeout checking

    }//end of while

    if (status == MSSP1_I2C_MESSAGE_COMPLETE) {
        LED_OFF();
        sprintf(tmp_string, "INA inti OK!");
        OLED_string(tmp_string, 0, 6);
        ssd1306_SPI_display(); //draw
        //__delay_ms(500);
        LED_ON();
        // __delay_ms(500);
        LED_OFF();
    }

    if (status == MSSP1_I2C_MESSAGE_ADDRESS_NO_ACK) {

        sprintf(tmp_string, "INA NoACK!");
        OLED_string(tmp_string, 0, 6);
        ssd1306_SPI_display(); //draw
        __delay_ms(300);

    }
    // counter++;
    ClrWdt();
    // } //end INA init  write while
    //}//end of For

    LED_OFF();
    SSD1306_clearDisplay();

    //-----------------MCP9808 init-------------------------
    //setting alart output and Temp. limts 
    int16_t T_lim_H, T_lim_L, T_lim_C;
    T_lim_H = T_limit_H << 4;
    T_lim_L = T_limit_L << 4;
    T_lim_C = T_limit_Critical << 4;
    writeBuffer[0] = 0x01; //reg address
    writeBuffer[1] = 0x00; //
    writeBuffer[2] = 0x0C; // Alart enable, TA>TC Alert active
    MSSP1_I2C_MasterWrite(writeBuffer, 3, MCP9808, &status);
    slaveTimeOut = 0;
    while (status == MSSP1_I2C_MESSAGE_PENDING) {
        // add some delay here
        __delay_us(1);
        // timeout checking
        // check for max retry and skip this byte
        slaveTimeOut++;
    }//end of while
    writeBuffer[0] = 0x02; // upper limit reg address
    writeBuffer[1] = T_lim_H >> 8; //
    writeBuffer[2] = (T_lim_H << 8) >> 8; // Alart enable

    MSSP1_I2C_MasterWrite(writeBuffer, 3, MCP9808, &status);
    slaveTimeOut = 0;
    while (status == MSSP1_I2C_MESSAGE_PENDING) {
        // add some delay here
        __delay_us(1);
        // timeout checking
        // check for max retry and skip this byte
        slaveTimeOut++;
    }//end of while
    //setting lowwer limit
    writeBuffer[0] = 0x03; // upper limit reg address
    writeBuffer[1] = T_lim_L >> 8; //
    writeBuffer[2] = (T_lim_L << 8) >> 8; // Alart enable

    MSSP1_I2C_MasterWrite(writeBuffer, 3, MCP9808, &status);
    while (status == MSSP1_I2C_MESSAGE_PENDING) {
        // add some delay here
        __delay_us(1);
        // timeout checking
        // check for max retry and skip this byte
        slaveTimeOut++;
    }//end of while
    writeBuffer[0] = 0x04; // upper limit reg address
    writeBuffer[1] = T_lim_C >> 8; //
    writeBuffer[2] = (T_lim_C << 8) >> 8; // Alart enable

    MSSP1_I2C_MasterWrite(writeBuffer, 3, MCP9808, &status);
    while (status == MSSP1_I2C_MESSAGE_PENDING) {
        // add some delay here
        __delay_us(1);
        // timeout checking
        // check for max retry and skip this byte
        slaveTimeOut++;
    }//end of while

    if (status == MSSP1_I2C_MESSAGE_COMPLETE) {
        //LED_OFF();
        sprintf(tmp_string, "MCP9808  OK!");
        OLED_string(tmp_string, 0, 4);
        ssd1306_SPI_display(); //draw
        __delay_ms(500);

    }


    //sprintf(tmp_string, "ZNCD INA TEST");
    // OLED_string(tmp_string, 0, 0);
    sprintf(tmp_string, "run!");
    OLED_string(tmp_string, 0, 0);

    ssd1306_SPI_display(); //draw
    __delay_ms(600);
    SSD1306_clearDisplay();

    double Power_mAh_tmp = 0;
    double Power_mWh_tmp = 0;
    while (1) {
        LED_ON();
        timeOut = 0;
        slaveTimeOut = 0;
        readBuffer[0] = 0;
        readBuffer[1] = 0;
        //--------AKKU Spanung measure

        /*  
      ADC1_Enable();
      //UART1_R_Buffer[0] = 0;
      ADC1_ChannelSelect(ADC1_CHANNEL_AN11); //AN5
      ADC_conversion = adc_12bit();
      //US1 = (float) ADC_conversion * Vref_ADC / 4095.0;
      US1 = (float) ADC_conversion;
      US1 = US1 * Vref_ADC / 4095.0;

      __delay_us(10);

      ADC1_Disable();



         */

        writeBuffer[0] = Bus_Voltage_reg;
        // write one byte to EEPROM (3 is the number of bytes to write)

        Vbus_raw = INA233_get_value(Bus_Voltage_reg);
        //test debug code:
        // tmp_H = (Vbus_raw << 8) >> 8; //LSB first
        //tmp_L = Vbus_raw >> 8;
        //set_font_size(0);
        //sprintf(tmp_string, "H:%d,L:%d", tmp_H, tmp_L);
        //OLED_string(tmp_string, 0, 0);
        //set_font_size(1);
        Vbus = Vbus_raw * 40960 / 32768; //voltage in mili volt 
        // Vbus = ((tmp_H << 8) + tmp_L)*40960 / 32768; //voltage in mili volt
        Vbus = Vbus*V_scale; // in mili volt 
        //sprintf(tmp_string, "Vbus:%3d", (int)Vbus / 1000);
        // OLED_string(tmp_string, 0, 0);
        Vbus_volt = Vbus / 1000.0; // convert to volt
        Vbus_mili = (int) (          Vbus - (      (int) (Vbus / 1000 )    )* 1000     );
        if (Vbus_mili < 10) //add zero charac.
            sprintf(tmp_string, "Vin:%2d.00%1d V", (int) (Vbus / 1000.0), Vbus_mili); //bugs?
        if (Vbus_mili < 100) //add zero charac.
            sprintf(tmp_string, "Vin:%2d.0%2d V", (int) (Vbus / 1000.0), Vbus_mili);
        else
            sprintf(tmp_string, "Vin:%2d.%3d V", (int) (Vbus / 1000.0), Vbus_mili);
        OLED_string(tmp_string, 0, 4);
        //above time interval between IIC Vbus read and IIC Current read is about 730 us
        //---------------get currents--------------
        Current_mA = INA233_get_value(Current_reg) * I_scale;
        Current_A = Current_mA / 1000.0;
        Current_mili = Current_mA - ((int) Current_A)*1000;
        if (Current_A > 2) {
            if (Current_mili < 100)
                sprintf(tmp_string, "I:%2d.0%2d A ", (int) Current_A, Current_mili);
            else
                sprintf(tmp_string, "I:%2d.%3d A ", (int) Current_A, Current_mili);
        } else sprintf(tmp_string, "I: %4d mA ", Current_mA);
        OLED_string(tmp_string, 0, 2);

        //    }

        //__delay_us(100);
        //above time interval between IIC Current read and MCP IIC is about 400 us
        //-------------^^^^^^^^^^^^^^^^^^----------------get INA power-----%%%%%%%%%%%%%%%%%%%%%%
        Power_raw = INA233_get_value(Power_reg);
        __delay_us(100);
        //calculate power 

        Power_mW = Vbus_volt * Current_mA;
        Power_W = Power_mW / 1000.0;


        set_font_size(0);
        sprintf(tmp_string, "P:%d W ", Power_raw * 2 / 10);
        // sprintf(tmp_string, "H:%d,L:%d", mcp_temp_H, mcp_temp_L);
        OLED_string(tmp_string, 80, 0);

        if (Power_mW > 9999) {
            //sprintf(tmp_string, "P:%3d W", (int) Power_W );
            sprintf(tmp_string, "P%3d.%2d W", (int) Power_W, (int) (Power_mW - ((int) Power_W)*1000));
        } else sprintf(tmp_string, "P:%4d mW ", (int) Power_mW);
        OLED_string(tmp_string, 64, 1);
        set_font_size(1);

        ///-----------------MCP9808----IIC---------
        writeBuffer[0] = 0x05; //T reg
        readBuffer[0] = 0;
        readBuffer[1] = 0;
        MSSP1_I2C_MasterWrite(writeBuffer, 1, MCP9808, &status);
        __delay_us(10);

        MSSP1_I2C_MasterRead(readBuffer, 2, MCP9808, &status);
        __delay_us(150);

        //if (status== MSSP1_I2C_MESSAGE_PENDING) {
        if (status == MSSP1_I2C_MESSAGE_COMPLETE) {
            mcp_temp_H = readBuffer[0] & 0x1F; //Clear flag bits 
            mcp_temp_L = readBuffer[1];
            Temperature = (double) mcp_temp_L;
            if ((mcp_temp_H & 0x10) == 0x10) { //TA < 0�C
                mcp_temp_H = mcp_temp_H & 0x0F; //Clear SIGN
                Temperature = 256 - (mcp_temp_H * 16 + Temperature / 16.0);
            } else //TA � 0�C
                Temperature = (mcp_temp_H * 16 + Temperature / 16.0);
            //Temperature = Ambient Temperature (�C)

        }

        // if ((Temperature - (int) Temperature)*1000 < 10) //add zero charac.
        //      sprintf(tmp_string, "T:%3d.00%1dC", (int) Temperature , (int)( (Temperature - (int) Temperature)* 1000));
        if ((Temperature - (int) Temperature)*1000 < 100) //add zero charac.
            sprintf(tmp_string, "T:%3d.0%1d C", (int) Temperature, (int) ((Temperature - (int) Temperature)* 100));
        else sprintf(tmp_string, "T:%3d.%2d C", (int) Temperature, (int) ((Temperature - (int) Temperature)* 100));
        //sprintf(tmp_string, "Temp: %3d. C", (int) Temperature);
        OLED_string(tmp_string, 0, 6);


        //writeBuffer[0]=0xaa;
        //  MSSP1_I2C_MasterWrite(writeBuffer, 1, 0x20, &status); 

        //end of test
        // sprintf(tmp_string, "timeOut %d", timeOut);
        //OLED_string(tmp_string, 0, 2);
        set_font_size(0);

        //counter = MSSP1_I2C_ErrorCountGet();
        sprintf(tmp_string, "Run:%d", cyc);
        //sprintf(tmp_string, "Run:%d,Er.%d ", cyc, counter);
        OLED_string(tmp_string, 0, 1);

        Power_mAs += Current_mA / 4; // 0.25s
        Power_mAh = Power_mAh_tmp + Power_mAs / 3600.0;
        Power_mWs += Power_mW / 4;
        sprintf(tmp_string, "%d mAh", (int) Power_mAh);
        //sprintf(tmp_string, "E:%d mAh %d mwh",  (int) Power_mAh, (int) Power_mWs);
        //sprintf(tmp_string, "Run:%d,Er.%d ", cyc, counter);
        OLED_string(tmp_string, 0, 0);

        set_font_size(1);
        ssd1306_SPI_display();


        if (cyc % 32 == 0) {
            set_font_size(0);
            Power_mWh = Power_mWh_tmp + Power_mWs / 3600.0;
            if (Power_mWh > 999)
                sprintf(tmp_string, "%dWh", (int) (Power_mWh / 1000.0));
            else sprintf(tmp_string, "%dmWh", (int) Power_mWh);
            OLED_string(tmp_string, 50, 0);

            if (Power_mAs > 72000) {
                Power_mAh_tmp += Power_mAs / 3600.0;
                Power_mAs = 0; //reset 20mAh
                Power_mWh_tmp += Power_mWs / 3600.0;
                Power_mWs = 0;
            }
            if (cyc > 9999) cyc = 0; //reset
            set_font_size(1);
        }
        LED_OFF();
        //processing time between LED on and off  is about 13ms!

        // Add your application code
        __delay_ms(Refresh_intval_tmp);
        ClrWdt();
        cyc++;
    }// end of while

    return -1;
}

unsigned int adc_12bit(void) {
    //ADC1_ChannelSelect(ADC1_CHANNEL_AN15);//works
    //ADC1_ChannelSelect(ADC1_CHANNEL_AN10);
    //NOP();
    ADC1_Start();
    __delay_us(20);
    //for (int i = 0; i < 1000; i++) {
    //}
    ADC1_Stop();
    //__delay_us(18);
    //LATAbits.LATA1=0;
    //LATAbits.LATA1=1;
    //28uS
    unsigned int conversion = 0;

    while (!ADC1_IsConversionComplete()) {
        ADC1_Tasks();
    }
    conversion = ADC1_ConversionResultGet();
    return conversion; //12bit
}

void ADC1_Disable(void) {

    AD1CON1bits.ADON = 0;
}

void ADC1_Enable(void) {

    AD1CON1bits.ADON = 1;
}

//OLED display:

void OLED_init(void) {
    LATAbits.LATA1 = 1; //led

    //reset
    LATAbits.LATA4 = 1;
    LATAbits.LATA3 = 1; //working
    __delay_ms(1);
    LATAbits.LATA4 = 0;
    LATAbits.LATA3 = 0;
    __delay_ms(100);
    LATAbits.LATA4 = 1;
    LATAbits.LATA3 = 1;
    __delay_us(20);
    SPI_enable();
    //uint8_t SPI_WriteBuffer[MY_BUFFER_SIZE];
    LATBbits.LATB15 = 0; //CD signal to low for cmd
    // Init sequence
    ssd1306_command(SSD1306_DISPLAYOFF); // 0xAE
    ssd1306_command(SSD1306_SETDISPLAYCLOCKDIV); // 0xD5 ??
    ssd1306_command(0x80); // the suggested ratio 0x80

    ssd1306_command(SSD1306_SETMULTIPLEX); // 0xA8
    ssd1306_command(SSD1306_LCDHEIGHT - 1); //63   0x3F

    ssd1306_command(SSD1306_SETDISPLAYOFFSET); // 0xD3
    ssd1306_command(0x0); // no offset
    ssd1306_command(SSD1306_SETSTARTLINE | 0x0); // line #0
    ssd1306_command(SSD1306_CHARGEPUMP); // 0x8D
    ssd1306_command(0x14);

    ssd1306_command(SSD1306_MEMORYMODE); // 0x20
    ssd1306_command(0x00); // 0x0 act like ks0108
    ssd1306_command(SSD1306_SEGREMAP | 0x1);
    ssd1306_command(SSD1306_COMSCANDEC);


    ssd1306_command(SSD1306_SETCOMPINS); // 0xDA   ??
    ssd1306_command(0x12);
    ssd1306_command(SSD1306_SETCONTRAST); // 0x81  ??
    ssd1306_command(0xCF);

    ssd1306_command(SSD1306_SETPRECHARGE); // 0xd9
    ssd1306_command(0xF1);
    ssd1306_command(SSD1306_SETVCOMDETECT); // 0xDB
    ssd1306_command(0x40);
    ssd1306_command(SSD1306_DISPLAYALLON_RESUME); // 0xA4
    ssd1306_command(SSD1306_NORMALDISPLAY); // 0xA6

    ssd1306_command(SSD1306_DEACTIVATE_SCROLL);

    ssd1306_command(SSD1306_DISPLAYON); //--turn on oled panel  0xA5  Entire Display ON

    //SPI_disable();
}

void ssd1306_SPI_command(uint8_t c) {

    // SPI

    LATBbits.LATB15 = 0;
    MSSP2_SPI_Exchange8bit(c);
    LATBbits.LATB15 = 1;
}

void ssd1306_Data(uint8_t c) {

    // SPI

    LATBbits.LATB15 = 1; //D/C# pin high
    MSSP2_SPI_Exchange8bit(c);
    LATBbits.LATB15 = 1;
}

void ssd1306_SPI_display(void) {

    // SPI
    LATBbits.LATB15 = 0; //D/C#
    ssd1306_SPI_command(SSD1306_COLUMNADDR);
    ssd1306_SPI_command(0); // Column start address (0 = reset)
    ssd1306_SPI_command(SSD1306_LCDWIDTH - 1); // Column end address (127 = reset)

    ssd1306_SPI_command(SSD1306_PAGEADDR);
    ssd1306_SPI_command(0); // Page start address (0 = reset)
#if SSD1306_LCDHEIGHT == 64
    ssd1306_SPI_command(7); // Page end address
#endif
#if SSD1306_LCDHEIGHT == 32
    ssd1306_SPI_command(3); // Page end address
#endif
#if SSD1306_LCDHEIGHT == 16
    ssd1306_SPI_command(1); // Page end address
#endif
    NOP();
    __delay_us(1);
    LATBbits.LATB15 = 1; //D/C#
    //MSSP2_SPI_Exchange8bit(0x10);
    uint16_t i = 0;
    for (i = 0; i < (SSD1306_LCDWIDTH * SSD1306_LCDHEIGHT / 8); i++) {
        // MSSP2_SPI_Exchange8bit(buffer[i]);
        //MSSP2_SPI_Exchange8bit(1);
        //MSSP2_SPI_Exchange8bit(0xFF);
        MSSP2_SPI_Exchange8bit(FC_buffer[i]); //logo
        //NOP();
        //__delay_us(1);
    }
    //LATBbits.LATB15 = 1 ;


}

void set_font_size(char t) {

    OLED_FontSize = t;

}

void SSD1306_clearDisplay(void) {
    memset(FC_buffer, 0, (SSD1306_LCDWIDTH * SSD1306_LCDHEIGHT / 8));
}


// the most basic function, set a single pixel
/*
void drawPixel(int16_t x, int16_t y, uint16_t color) {
    if ((x < 0) || (x >= SSD1306_LCDWIDTH) || (y < 0) || (y >= SSD1306_LCDHEIGHT))
        return;

    /*
    // check rotation, move pixel around if necessary
    switch (getRotation()) {
    case 1:
      ssd1306_swap(x, y);
      x = WIDTH - x - 1;
      break;
    case 2:
      x = WIDTH - x - 1;
      y = HEIGHT - y - 1;
      break;
    case 3:
      ssd1306_swap(x, y);
      y = HEIGHT - y - 1;
      break;
    }
 */

/*
// x is which column
switch (color) {
    case WHITE: FC_buffer[x + (y / 8) * SSD1306_LCDWIDTH] |= (1 << (y & 7));
        break;
    case BLACK: FC_buffer[x + (y / 8) * SSD1306_LCDWIDTH] &= ~(1 << (y & 7));
        break;
    case INVERSE: FC_buffer[x + (y / 8) * SSD1306_LCDWIDTH] ^= (1 << (y & 7));
        break;
}

}

 */

void OLED_char_0(char character, short x, short y) {
    short table_offset = (character - 0x20);
    short Pix_offset = y * 128 + x;
    if (Pix_offset > 1023) Pix_offset = 0;
    unsigned int i = 0;
    for (i = 0; i < 6; i++) FC_buffer[Pix_offset + i ] = F6x8[table_offset][i];

}

void OLED_char_1(char character, short x, short y) {

    short table_offset = 16 * (character - 0x20);
    short Pix_offset = y * 128 + x;
    if (Pix_offset > 1023) Pix_offset = 0;
    char i = 0;
    for (i = 0; i < 8; i++)
        FC_buffer[Pix_offset + i ] = F8X16[table_offset + i];
    for (i = 0; i < 8; i++)
        FC_buffer[Pix_offset + i + 128] = F8X16[table_offset + i + 8];
    //for (char i = 0; i < 8; i++) FC_buffer[512 ] = F6x8[16 + i];
    //for (char i = 0; i < 8; i++) FC_buffer[512 + i + 128] = F6x8[16 + i+8];

}

void OLED_string(char* str, short x, short y) {
    //x col position  0-127
    //y row position  0-7
    short pos = 0;
    char character = str[pos++];
    short startx = x;
    short starty = y;
    while (character != '\0') {

        if (OLED_FontSize) {
            if (startx >= 120) {
                starty++; //wrap around
                startx = 0;
            }
            OLED_char_1(character, startx, starty);
            startx += 8;
            character = str[pos++];

        } else {
            if (startx >= 122) {
                starty++; //wrap around
                startx = 0;
            }
            OLED_char_0(character, startx, starty);
            startx += 6;
            character = str[pos++];
        }
    }
}

void ssd1306_command(uint8_t c) {
    // SPI
    LATBbits.LATB15 = 0; //RB15  OLED  D/C#
    MSSP2_SPI_Exchange8bit(c);

}
//---INA233---

//get current value in A

uint16_t INA233_get_value(uint8_t reg) {
    writeBuffer[0] = reg;
    int16_t res = 0;
    uint8_t IIC_Timeout = 0;
    readBuffer[0] = 0;
    readBuffer[1] = 0;
    // write one byte to EEPROM (3 is the number of bytes to write)
    MSSP1_I2C_MESSAGE_STATUS status;
    MSSP1_I2C_MasterWrite(writeBuffer, 1, INA_add, &status); // uint8_t *pdata ---> writeBuffer
    while (status == MSSP1_I2C_MESSAGE_PENDING) {
        __delay_us(1);
        if (IIC_Timeout == 255) {
            res = 0;
            return res;
            // break;
        } else
            IIC_Timeout++;
    }
    if (status == MSSP1_I2C_MESSAGE_ADDRESS_NO_ACK) {
        res = 0;
        sprintf(tmp_string, "IIC NoACK!");
        OLED_string(tmp_string, 0, 6);
        ssd1306_SPI_display(); //draw
        // __delay_ms(500);
        //ssd1306_SPI_display(); //draw
        __delay_ms(200);
        return res;
    }

    if (reg == Energy_reg) {
        MSSP1_I2C_MasterRead(readBuffer, 7, INA_add, &status);
        __delay_us(200);
        res = readBuffer[1]+ (readBuffer[2] << 8);

        return res;



    } else {
        MSSP1_I2C_MasterRead(readBuffer, 2, INA_add, &status);
        __delay_us(120);
        res = readBuffer[0]+ (readBuffer[1] << 8);

        return res;
    }
}



//iic sample code
/*
// write one byte to EEPROM (3 is the number of bytes to write)
                MSSP1_I2C_MasterWrite(  writeBuffer,
                                        3,
                                        slaveDeviceAddress,
                                        &status);
 */
// End of File
