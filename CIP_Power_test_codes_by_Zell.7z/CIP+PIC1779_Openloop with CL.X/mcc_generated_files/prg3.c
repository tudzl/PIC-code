/**
  PRG3 Generated Driver  File

  @Company
    Microchip Technology Inc.

  @File Name
    prg3.c

  @Summary
    This is the generated driver implementation for the PRG3 driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This source file provides APIs for PRG3.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1779
        Driver Version    :  2.01
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.36 and above
        MPLAB 	          :  MPLAB X 6.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

/**
  Section: Included Files
*/

#include <xc.h>
#include "prg3.h"

/**
  Section: PRG3 APIs
*/

void PRG3_Initialize(void)
{
    // RG3GO not operating; RG3EN enabled; RG3MODE slope compensation; RG3OS disabled; RG3REDG edge_sensitive; RG3FEDG edge_sensitive; 
    PRG3CON0 = 0xB0;
    // RG3FPOL active_low; RG3RPOL active_high; 
    PRG3CON1 = 0x02;
    // INS FVR_buffer2; 
    PRG3INS = 0x02;
    // RG3ISET 2.00  V/us; 
    PRG3CON2 = 0x1A;
    // RTSS PWM11_output; 
    PRG3RTSS = 0x0E;
    // FTSS PWM11_output; 
    PRG3FTSS = 0x0E;

}

bool PRG3_IsReady(void)
{
    return (PRG3CON1bits.RG3RDY);
}

void PRG3_StartRampGeneration(void)
{
    // Start the PRG module by set GO bit
    PRG3CON0bits.RG3GO = 1;
}

void PRG3_StopRampGeneration(void)
{
    // Stop the PRG module by clearing GO bit
    PRG3CON0bits.RG3GO = 0;
}

void PRG3_EnableOneShot(void)
{
    // Enable One-Shot mode by setting OS bit
    PRG3CON0bits.RG3OS = 1;
}

void PRG3_DisableOneShot(void)
{
    // Disable One-Shot mode by clearing OS bit
    PRG3CON0bits.RG3OS = 0;
}

void PRG3_UpdateSlope(uint8_t slopeValue )
{
    PRG3CON2bits.RG3ISET = (slopeValue & 0x1F);
}

/**
 End of File
*/
