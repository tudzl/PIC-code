/*
    (c) 2019 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
 */

/**
  Section: Included Files
 */

#include "pcmc.h"
#include "compensator_blk.h"
#include "pcmc_modblk.h"

/**
  Section: PCMC APIs
 */

void PCMC_Initialize(void) {
    PcmcModBlock_PPS_Setup();
    PCMC_SoftStart();
}

void PCMC_SoftStart(void) {
    uint16_t PWMlimit, DAClimit, BLANKlimit;
    uint16_t ctr = 0;

    PWMlimit = PcmcModBlock_PWM_GetDutyCycle();
    BLANKlimit = PcmcModBlock_PWM_BlankingGet();
    DAClimit = CompensatorBlock_DAC_ReadInputData();

    CompensatorBlock_DAC_LoadInputData(0);
    PcmcModBlock_PWM_SetDutyCycle(0);
    PcmcModBlock_PWM_BlankingSet(0);

    CompensatorBlock_OPA_Start();
    PcmcModBlock_PWM_Start();
    // fire up the PRG generation
    PcmcModBlock_PRG_StartSequence();
    PcmcModBlock_COG_Start();

    while ((ctr++) < PWMlimit) {
        if(ctr <= BLANKlimit){
            PcmcModBlock_PWM_BlankingSet(ctr);
        }
        PcmcModBlock_PWM_SetDutyCycle(ctr);
    }

    ctr = 0;

    while ((ctr++) < DAClimit) {
        CompensatorBlock_DAC_LoadInputData(ctr);
    }
}

void PCMC_SetReference(uint16_t dacValue) {
   CompensatorBlock_DAC_LoadInputData(dacValue);
}

uint16_t PCMC_GetReference(void){
   return CompensatorBlock_DAC_ReadInputData();
}

void PCMC_PRG_StartSequence(void){
    PcmcModBlock_PRG_StartSequence();
}
