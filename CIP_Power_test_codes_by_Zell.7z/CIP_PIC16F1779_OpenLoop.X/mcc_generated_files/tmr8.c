/**
  TMR8 Generated Driver File

  @Company
    Microchip Technology Inc.

  @File Name
    tmr8.c

  @Summary
    This is the generated driver implementation file for the TMR8 driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This source file provides APIs for TMR8.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.8
        Device            :  PIC16F1779
        Driver Version    :  2.11
    The generated drivers are tested against the following:
        Compiler          :  XC8 2.36 and above 
        MPLAB 	          :  MPLAB X 6.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

/**
  Section: Included Files
*/

#include <xc.h>
#include "tmr8.h"
extern uint8_t TMR_500ms_flag;
/**
  Section: Global Variables Definitions
*/

void (*TMR8_InterruptHandler)(void);

/**
  Section: TMR8 APIs
*/

void TMR8_Initialize(void)
{
    // Set TMR8 to the options selected in the User Interface

    // T8CS LFINTOSC; 
    T8CLKCON = 0x04;

    // T8PSYNC Not Synchronized; T8MODE Software control; T8CKPOL Rising Edge; T8CKSYNC Not Synchronized; 
    T8HLT = 0x00;

    // T8RSEL T8CKIPPS pin; 
    T8RST = 0x00;

    // T8PR 29; 
    T8PR = 0x1D;

    // TMR8 0; 
    T8TMR = 0x00;

    // Clearing IF flag before enabling the interrupt.
    PIR4bits.TMR8IF = 0;

    // Enabling TMR8 interrupt.
    PIE4bits.TMR8IE = 1;

    // Set Default Interrupt Handler
    TMR8_SetInterruptHandler(TMR8_DefaultInterruptHandler);

    // T8CKPS 1:64; T8OUTPS 1:8; TMR8ON on; 
    T8CON = 0xE7;
}

void TMR8_ModeSet(TMR8_HLT_MODE mode)
{
   // Configure different types HLT mode
    T8HLTbits.MODE = mode;
}

void TMR8_ExtResetSourceSet(TMR8_HLT_EXT_RESET_SOURCE reset)
{
    //Configure different types of HLT external reset source
    T8RSTbits.RSEL = reset;
}

void TMR8_Start(void)
{
    // Start the Timer by writing to TMRxON bit
    T8CONbits.TMR8ON = 1;
}

void TMR8_StartTimer(void)
{
    TMR8_Start();
}

void TMR8_Stop(void)
{
    // Stop the Timer by writing to TMRxON bit
    T8CONbits.TMR8ON = 0;
}

void TMR8_StopTimer(void)
{
    TMR8_Stop();
}

uint8_t TMR8_Counter8BitGet(void)
{
    uint8_t readVal;

    readVal = TMR8;

    return readVal;
}

uint8_t TMR8_ReadTimer(void)
{
    return TMR8_Counter8BitGet();
}

void TMR8_Counter8BitSet(uint8_t timerVal)
{
    // Write to the Timer8 register
    TMR8 = timerVal;
}

void TMR8_WriteTimer(uint8_t timerVal)
{
    TMR8_Counter8BitSet(timerVal);
}

void TMR8_Period8BitSet(uint8_t periodVal)
{
   PR8 = periodVal;
}

void TMR8_LoadPeriodRegister(uint8_t periodVal)
{
   TMR8_Period8BitSet(periodVal);
}

void TMR8_ISR(void)
{

    // clear the TMR8 interrupt flag
    PIR4bits.TMR8IF = 0;
   
    if(TMR8_InterruptHandler)
    {
        TMR8_InterruptHandler();
    }
}


void TMR8_SetInterruptHandler(void (* InterruptHandler)(void)){
    TMR8_InterruptHandler = InterruptHandler;
}

void TMR8_DefaultInterruptHandler(void){
    // add your TMR8 interrupt custom code
    // or set custom function using TMR8_SetInterruptHandler()
        TMR_500ms_flag =1;
}



/**
  End of File
*/