% LVPFC Cascaded Controller
% Define Phase and Gain Margin
% Specify Plant Parameters
% Generates 2P2Z Cascaded Controller Coefficients
% Specify gain to multiply B coefficients (Shift)
% Coefficients written to "voltage_dcdt.h"
% Include file "voltage_dcdt.h" in LVPFC MPLABx project	

clc
clear all
close all

s = tf('s');
z = tf('z');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Voltage Loop Controller Design
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Constants
pi = 22/7;

% Define desired phase margin and crossover frequency (degrees and Hz)
pm = 60;    % Phase Margin (Hz)
fc = 10;    % Crossover Frequency (Hz)

% Power Stage Parameters
Vin = 26;       % Maximum Input Voltage (V)
Vo = 40;        % Typical Output Voltage (V)
Io = 1.25;      % Maximum Load Current (A)
L = 25e-6;      % Effective Inductance L/2 (H)
Co = 3000e-6;   % Output Capacitance (F)
Resr = 3e-3;    % Output Capacitance ESR (Ohm)
Eff = 0.9;      % Efficiency assumed

% Frequency Parameters
Fs = 6000;          % Sampling frequency (Hz)
Ts = 1/Fs;          % Sampling time (s)
Tres = 4.237e-9;    % PWM Resolution (s)
Fpwm = 30000;       % Minimum switching frequency (Hz)
Hpwm = Tres*Fpwm;   % PWM gain

% Feedback Parameters
Hdiv = 0.068;           % Resistive divider gain
Nadc = 12;              % ADC bits
Vadc = 3.3;             % ADC reference voltage (V)
Hadc = (2^Nadc-1)/Vadc; % ADC gain

% Kuc gain
Kuc = 1/(Hdiv*Hadc*Hpwm);   % Multiplies B Coeffs

% Plant Transfer function
Ro = Vo/Io;
g1 = (Vin^2/(2*Vo))*Ro/2;
wp = 2/(Ro*Co);
wo = 1/(Resr*Co);
Gplant = tf([g1/wo, g1],[1/wp 1]);

% Synthesize the k-factor controller
controller_v = k_factor_function(Gplant, fc, pm);

% Options for Bode plot of loop
opts = bodeoptions('cstprefs');
opts.FreqUnits = 'Hz';
opts.PhaseWrapping = 'off';

% Bode plot of voltage loop
bode(controller_v*Gplant, opts), grid, xlim([1 1e3])

% Discretize the Controller
controller_d = c2d(Kuc*controller_v, Ts, 'Tustin');

% Q15 representation of cascaded controller
% To counter effect of smaller B coefficients
% Define 'gainShift' as power of 2
% Ex: If 3 is passed, B10*2^3, B11*2^3, PostShift = 3 (1/2^3)
% Best value of 'Shift' varies with design
[z_K, p_K, k_K] = zpkdata(controller_d, 'v');

gainShift = 3;

gain = k_K*2^gainShift;

Pc = sort(p_K, 'ascend');
Zc = sort(z_K, 'ascend');

gainArray = [gain, 1];

it_no = 1;
for it_no = 1:length(Pc)
    Kd([it_no]) = (z-Zc(it_no))/(z-Pc(it_no));
     
    num_Q15 = round([1 -Zc(it_no)].*(gainArray(it_no)*32767));
    den_Q15 = round([1 -Pc(it_no)].*32767);
    Kd_fp([it_no]) = tf(num_Q15, den_Q15, Ts)

    it_no = it_no + 1;
end

fid = fopen('voltage_dcdt.h','w');
fprintf(fid,"%s\n", '#ifndef _VOLTAGE_DCDT_DEFINES_H');
fprintf(fid,"%s\n\n", '#define _VOLTAGE_DCDT_DEFINES_H');
fprintf(fid,"%s\n", '/* Compensator Coefficient Defines */');

fprintf(fid,"\n");
fprintf(fid,"%s\n", '/* K1(z) */');
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_COEFF_B10 %d\n",round(gainArray(1)*32767));
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_COEFF_B11 %d\n",round(-Zc(1)*gainArray(1)*32767));
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_COEFF_A11 %d\n",round(Pc(1)*32767));
fprintf(fid,"\n");

fprintf(fid,"%s\n", '/* K2(z) */');
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_COEFF_B20 %d\n",round(gainArray(2)*32767));
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_COEFF_B21 %d\n",round(-Zc(2)*gainArray(2)*32767));
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_COEFF_A21 %d\n",round(Pc(2)*32767));
fprintf(fid,"\n");

fprintf(fid,"%s\n", '/* K3(z) Bypass for 2P2Z */');
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_COEFF_B30 %d\n",32767);
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_COEFF_B31 %d\n",0);
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_COEFF_A31 %d\n",0);
fprintf(fid,"\n");

fprintf(fid,"%s\n", '/* Scaling Coefficients */');
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_POSTSCALER %d\n",32767);
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_POSTSHIFT %d\n",gainShift);
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_PRESHIFT %d\n",0);
fprintf(fid,"\n");

fprintf(fid,"%s\n", '/* Compensator Clamp Limits */');
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_MIN_CLAMP %d\n",0);
fprintf(fid,"#define VOLTAGE_COMP_2P2Z_MAX_CLAMP %d\n",2500);
fprintf(fid,"\n");
fprintf(fid,"%s\n", '#endif');

fclose(fid);

cascaded_fp_controller = Kd_fp;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% K-factor Subroutine Definition
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function controller = k_factor_function(G, fc, pm)

s = tf('s');

%  Program calculations
wc = 2*pi*fc;
sc = 2*pi*j*fc;

G_wc = evalfr(G,sc);  % Plant response at the desired crossover frequency.

%  NOTE!!!  In instances where the phase of the plant is near 180 degrees,
%  the sign of the phase will be incorrect (+/-).  This will result in
%  incorrect controller selection.
G_phase = atan2(imag(G_wc), real(G_wc));  %atan(imag(G_wc)/real(G_wc));  

%  Based on the comment above, if the phase is greater than +120 degrees, it
%  is assumed to be a phase lag (change the sign).  
if G_phase > 2.0944
    G_phase = -G_phase;
end

G_mag = sqrt(real(G_wc)^2 + imag(G_wc)^2);

required_phase_boost = (-90 - G_phase*180/pi + pm);

if required_phase_boost < 0 
    L_init = G/s;
    L_init_wc = evalfr(L_init, sc);
    kc = 1/abs(L_init_wc);

    controller = kc/s;
end

if required_phase_boost >= 0 & required_phase_boost < 90 
    k = tan((required_phase_boost/2 + 45)*pi/180);
    wz = wc/k;
    wp = k*wc;
    L_init = G*(1 + s/wz)/(s*(1 + s/wp));
    L_init_wc = evalfr(L_init, sc);
    kc = 1/abs(L_init_wc);
    controller = kc*(1 + s/wz)/(s*(1 + s/wp));
end

if required_phase_boost >= 90 
    k = tan((required_phase_boost/4 + 45)*pi/180);
    wz = wc/k;
    wp = k*wc;
    L_init = G*(1 + s/wz)^2/(s*(1 + s/wp)^2);
    L_init_wc = evalfr(L_init, sc);
    kc = 1/abs(L_init_wc);
    controller = kc*(1 + s/wz)^2/(s*(1 + s/wp)^2);
end

controller = minreal(controller);

end

